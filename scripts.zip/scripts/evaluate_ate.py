import argparse
import os

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# ==============================================================
# Load estimated trajectory
# ==============================================================

def load_estimated(path):

    df = pd.read_csv(path)

    df.columns = [
        c.strip()
        for c in df.columns
    ]

    # Handle common column names.
    rename = {}

    for c in df.columns:

        cl = c.lower()

        if cl in ["timestamp", "time", "t", "t_ns"]:
            rename[c] = "t"

        elif cl in ["px", "x", "p_x"]:
            rename[c] = "x"

        elif cl in ["py", "y", "p_y"]:
            rename[c] = "y"

        elif cl in ["pz", "z", "p_z"]:
            rename[c] = "z"

    df = df.rename(columns=rename)

    required = [
        "t",
        "x",
        "y",
        "z"
    ]

    for c in required:

        if c not in df.columns:
            raise RuntimeError(
                f"trajectory.csv is missing '{c}'. "
                f"Columns found: {list(df.columns)}"
            )

    t = df["t"].to_numpy(
        dtype=np.float64
    )

    # Detect nanoseconds.
    if np.median(np.abs(t)) > 1e12:
        t *= 1e-9

    p = df[
        ["x", "y", "z"]
    ].to_numpy(
        dtype=np.float64
    )

    return t, p


# ==============================================================
# Load EuRoC ground truth
# ==============================================================

def load_groundtruth(dataset):

    path = os.path.join(
        dataset,
        "mav0",
        "state_groundtruth_estimate0",
        "data.csv"
    )

    if not os.path.isfile(path):

        raise FileNotFoundError(
            f"Ground truth not found:\n{path}"
        )

    df = pd.read_csv(path)

    df.columns = [
        c.strip()
        for c in df.columns
    ]

    # EuRoC format:
    #
    # timestamp,
    # p_RS_R_x,
    # p_RS_R_y,
    # p_RS_R_z,
    # q_RS_w,
    # q_RS_x,
    # q_RS_y,
    # q_RS_z,
    # ...

    cols = list(df.columns)

    t = df[cols[0]].to_numpy(
        dtype=np.float64
    )

    if np.median(np.abs(t)) > 1e12:
        t *= 1e-9

    p = df[
        [
            cols[1],
            cols[2],
            cols[3]
        ]
    ].to_numpy(
        dtype=np.float64
    )

    return t, p


# ==============================================================
# Match timestamps
# ==============================================================

def associate(
    est_t,
    est_p,
    gt_t,
    gt_p,
    max_dt=0.02
):

    est_out = []
    gt_out = []
    times = []

    for i, t in enumerate(est_t):

        j = np.searchsorted(
            gt_t,
            t
        )

        candidates = []

        if j < len(gt_t):
            candidates.append(j)

        if j > 0:
            candidates.append(j - 1)

        if not candidates:
            continue

        j = min(
            candidates,
            key=lambda k:
            abs(gt_t[k] - t)
        )

        dt = abs(
            gt_t[j] - t
        )

        if dt <= max_dt:

            est_out.append(
                est_p[i]
            )

            gt_out.append(
                gt_p[j]
            )

            times.append(t)

    if len(est_out) < 3:

        raise RuntimeError(
            "Could not associate enough "
            "estimated/ground-truth poses."
        )

    return (
        np.asarray(times),
        np.asarray(est_out),
        np.asarray(gt_out)
    )


# ==============================================================
# SE(3) alignment
# ==============================================================

def align_se3(
    estimated,
    groundtruth
):

    # Center both trajectories.
    mu_est = np.mean(
        estimated,
        axis=0
    )

    mu_gt = np.mean(
        groundtruth,
        axis=0
    )

    X = (
        estimated -
        mu_est
    )

    Y = (
        groundtruth -
        mu_gt
    )

    # Cross covariance.
    H = X.T @ Y

    U, S, Vt = np.linalg.svd(H)

    R = Vt.T @ U.T

    # Reflection correction.
    if np.linalg.det(R) < 0:

        Vt[-1, :] *= -1

        R = Vt.T @ U.T

    t = (
        mu_gt -
        R @ mu_est
    )

    aligned = (
        (R @ estimated.T).T +
        t
    )

    return aligned, R, t


# ==============================================================
# Initial-pose alignment
# ==============================================================

def align_first_pose(
    estimated,
    groundtruth
):

    # Translation-only alignment.
    offset = (
        groundtruth[0] -
        estimated[0]
    )

    return (
        estimated +
        offset
    )


# ==============================================================
# Metrics
# ==============================================================

def calculate_errors(
    estimated,
    groundtruth
):

    e = (
        estimated -
        groundtruth
    )

    norms = np.linalg.norm(
        e,
        axis=1
    )

    return norms


def rmse(x):

    return np.sqrt(
        np.mean(
            x * x
        )
    )


# ==============================================================
# Relative pose error
# ==============================================================

def calculate_rpe(
    estimated,
    groundtruth,
    delta=10
):

    errors = []

    n = len(estimated)

    for i in range(
        n - delta
    ):

        est_rel = (
            estimated[i + delta] -
            estimated[i]
        )

        gt_rel = (
            groundtruth[i + delta] -
            groundtruth[i]
        )

        errors.append(
            np.linalg.norm(
                est_rel -
                gt_rel
            )
        )

    if not errors:
        return np.array([])

    return np.asarray(errors)


# ==============================================================
# Main
# ==============================================================

def main():

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--dataset",
        required=True
    )

    parser.add_argument(
        "--traj",
        default="trajectory.csv"
    )

    parser.add_argument(
        "--max-dt",
        type=float,
        default=0.02
    )

    parser.add_argument(
        "--plot",
        action="store_true"
    )

    args = parser.parse_args()

    print()
    print("=" * 70)
    print("EuRoC VIO Evaluation")
    print("=" * 70)

    # ----------------------------------------------------------
    # Load
    # ----------------------------------------------------------

    est_t, est_p = load_estimated(
        args.traj
    )

    gt_t, gt_p = load_groundtruth(
        args.dataset
    )

    print(
        f"Estimated poses : {len(est_p)}"
    )

    print(
        f"Groundtruth poses: {len(gt_p)}"
    )

    # ----------------------------------------------------------
    # Association
    # ----------------------------------------------------------

    (
        timestamps,
        est,
        gt
    ) = associate(
        est_t,
        est_p,
        gt_t,
        gt_p,
        args.max_dt
    )

    print(
        f"Matched poses    : {len(est)}"
    )

    print(
        f"Duration         : "
        f"{timestamps[-1] - timestamps[0]:.3f} s"
    )

    # ----------------------------------------------------------
    # Raw error
    # ----------------------------------------------------------

    raw_error = calculate_errors(
        est,
        gt
    )

    print()
    print("RAW (unaligned) ERROR")
    print(
        f"RMSE   : {rmse(raw_error):.4f} m"
    )

    print(
        f"Mean   : {np.mean(raw_error):.4f} m"
    )

    print(
        f"Median : {np.median(raw_error):.4f} m"
    )

    # ----------------------------------------------------------
    # Translation-only initial alignment
    # ----------------------------------------------------------

    est_first = align_first_pose(
        est,
        gt
    )

    first_error = calculate_errors(
        est_first,
        gt
    )

    print()
    print("FIRST-POSE TRANSLATION ALIGNMENT")
    print(
        f"RMSE   : {rmse(first_error):.4f} m"
    )

    print(
        f"Mean   : {np.mean(first_error):.4f} m"
    )

    # ----------------------------------------------------------
    # SE(3) alignment
    # ----------------------------------------------------------

    est_aligned, R, t = align_se3(
        est,
        gt
    )

    aligned_error = calculate_errors(
        est_aligned,
        gt
    )

    print()
    print("SE(3) ALIGNED ERROR")
    print(
        f"RMSE   : {rmse(aligned_error):.4f} m"
    )

    print(
        f"Mean   : {np.mean(aligned_error):.4f} m"
    )

    print(
        f"Median : {np.median(aligned_error):.4f} m"
    )

    print(
        f"Max    : {np.max(aligned_error):.4f} m"
    )

    # ----------------------------------------------------------
    # RPE
    # ----------------------------------------------------------

    rpe = calculate_rpe(
        est_aligned,
        gt,
        delta=10
    )

    if len(rpe):

        print()
        print("RELATIVE POSITION ERROR")
        print(
            f"RMSE   : {rmse(rpe):.4f} m"
        )

        print(
            f"Mean   : {np.mean(rpe):.4f} m"
        )

    # ----------------------------------------------------------
    # Plot
    # ----------------------------------------------------------

    if args.plot:

        fig = plt.figure(
            figsize=(14, 7)
        )

        ax1 = fig.add_subplot(
            1,
            2,
            1
        )

        ax1.plot(
            timestamps -
            timestamps[0],
            aligned_error
        )

        ax1.set_xlabel(
            "time (s)"
        )

        ax1.set_ylabel(
            "position error (m)"
        )

        ax1.set_title(
            "SE(3)-aligned error vs time"
        )

        ax1.grid(True)

        ax2 = fig.add_subplot(
            1,
            2,
            2
        )

        ax2.plot(
            est_aligned[:, 0],
            est_aligned[:, 1],
            label="Estimated"
        )

        ax2.plot(
            gt[:, 0],
            gt[:, 1],
            "--",
            label="Groundtruth"
        )

        ax2.set_xlabel(
            "x (m)"
        )

        ax2.set_ylabel(
            "y (m)"
        )

        ax2.set_title(
            "Top-down trajectory"
        )

        ax2.axis("equal")

        ax2.grid(True)

        ax2.legend()

        plt.tight_layout()

        plt.show()


if __name__ == "__main__":
    main()