#!/usr/bin/env python3
"""
Initialization health check.

Run this BEFORE a full pipeline run. Initialization errors are silent
over short horizons and fatal over long ones: because the bias
random-walk factor pins bias_j to bias_i far more stiffly than any
measurement can push back, whatever bias/attitude this step produces
is effectively frozen for the entire sequence. A ~0.25 deg
gravity-alignment tilt leaves ~0.04 m/s^2 of residual specific force,
which looks fine for 10 s and produces hundreds of metres of error
over 140 s.

Usage:
    python scripts/check_init.py /path/to/mav0
"""

import argparse
import os
import sys

import numpy as np

sys.path.insert(
    0,
    os.path.join(os.path.dirname(__file__), "..", "src")
)

from dataset import EuRoCDataset  # noqa: E402


GRAVITY_MAG = 9.81007

# Reference magnitudes for the EuRoC ADIS16448 -- RAW, uncalibrated
# sensor. These are noticeably larger than the sensor's noise-density
# spec sheet numbers: published EuRoC bias values for this IMU include
# e.g. bg=[-0.0023, 0.0249, 0.0817] rad/s, ba=[-0.0236, 0.1210, 0.0748]
# m/s^2. So these thresholds only catch genuinely extreme
# values (a window that was actually moving/falling), not the normal
# nonzero raw bias of this sensor.
EXPECTED_GYRO_BIAS = 0.1        # rad/s
EXPECTED_ACCEL_BIAS = 0.15      # m/s^2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dataset", help="Path to mav0 directory")
    ap.add_argument("--duration", type=float, default=0.5,
                    help="Static window length in seconds")
    ap.add_argument("--search", type=float, default=8.0,
                    help="How far into the sequence to search")
    ap.add_argument("--horizon", type=float, default=143.6,
                    help="Sequence length to extrapolate drift over")
    args = ap.parse_args()

    ds = EuRoCDataset(args.dataset)

    print("=" * 70)
    print("IMU INITIALIZATION HEALTH CHECK")
    print("=" * 70)

    # ------------------------------------------------------------------
    # 1. Static window search
    # ------------------------------------------------------------------
    rows, diag = ds.find_static_window(
        duration_s=args.duration,
        search_s=args.search
    )

    print("\n[1] STATIC WINDOW SEARCH")
    if rows is None:
        print("    STATUS: FAILED - no stationary window found")
        limits = diag.get("limits", (None, None, None))
        print(f"    best candidate gyro std     : {diag.get('best_gyro_std')} "
              f"(limit {limits[0]})")
        print(f"    best candidate accel std    : {diag.get('best_acc_std')} "
              f"(limit {limits[1]})")
        print(f"    best candidate accel norm err: {diag.get('best_acc_norm_err')} "
              f"(limit {limits[2]})")
        print("    -> whichever of the above exceeds its limit is why no")
        print("       window qualified. accel std/norm-err failing means")
        print("       genuine motion; gyro std failing (with accel clean)")
        print("       can still mean a large constant bias if it doesn't")
        print("       improve anywhere else in the search either -- try")
        print("       `--search` with a larger value to look further in.")
    else:
        print("    STATUS: OK")
        print(f"    found at t0+{diag['offset_s']:.2f}s, "
              f"{diag['n_samples']} samples")
        print(f"    max gyro std     : {diag['gyro_std']:.6f} rad/s "
              "(variance test -- what actually detects rotation)")
        print(f"    mean |gyro|      : {diag['gyro_mean_mag']:.6f} rad/s "
              "(this IS the raw bias -- normal for it to be nonzero)")
        print(f"    max accel std    : {diag['acc_std']:.4f} m/s^2")
        print(f"    mean |accel|     : {diag['acc_norm']:.4f} m/s^2 "
              f"(gravity {GRAVITY_MAG:.4f})")

    # ------------------------------------------------------------------
    # 2. Resulting init values
    # ------------------------------------------------------------------
    R0, bg, ba, t0_ns = ds.initialize_from_imu(duration_s=args.duration)

    bg_mag = float(np.linalg.norm(bg))
    ba_mag = float(np.linalg.norm(ba))

    print("\n[2] ESTIMATED INITIAL VALUES")
    print(f"    gyro  bias : {np.round(bg, 6)}  |bg| = {bg_mag:.6f} rad/s "
          f"({np.degrees(bg_mag):.3f} deg/s)")
    print(f"    accel bias : {np.round(ba, 6)}  |ba| = {ba_mag:.6f} m/s^2")

    gyro_ratio = bg_mag / EXPECTED_GYRO_BIAS
    accel_ratio = ba_mag / EXPECTED_ACCEL_BIAS

    print(f"    gyro  bias vs expected ({EXPECTED_GYRO_BIAS}): "
          f"{gyro_ratio:.1f}x  "
          f"{'OK' if gyro_ratio < 4 else '<-- TOO LARGE'}")
    print(f"    accel bias vs expected ({EXPECTED_ACCEL_BIAS}): "
          f"{accel_ratio:.1f}x  "
          f"{'OK' if accel_ratio < 4 else '<-- TOO LARGE'}")

    # ------------------------------------------------------------------
    # 3. Gravity alignment residual -> predicted drift
    # ------------------------------------------------------------------
    print("\n[3] PREDICTED DRIFT FROM THIS INITIALIZATION")

    if rows is not None:
        a_mean = np.median(rows[:, 4:7], axis=0)
        # Residual specific force after removing estimated bias and
        # rotating the measured gravity into the world frame.
        resid_vec = R0 @ (a_mean - ba) - np.array([0.0, 0.0, GRAVITY_MAG])
        resid = float(np.linalg.norm(resid_vec))
    else:
        resid = float("nan")

    if np.isfinite(resid):
        T = args.horizon
        print(f"    residual specific force : {resid:.5f} m/s^2")
        print(f"    tilt equivalent         : "
              f"{np.degrees(np.arcsin(min(resid / GRAVITY_MAG, 1.0))):.4f} deg")
        print(f"    -> velocity after {T:.0f}s : {resid * T:.2f} m/s")
        print(f"    -> position after {T:.0f}s : {0.5 * resid * T ** 2:.1f} m")
        print(f"    -> position after 10s      : "
              f"{0.5 * resid * 10 ** 2:.3f} m   "
              f"(this is why short runs look healthy)")

    print("\n" + "=" * 70)
    ok = (
        rows is not None and
        gyro_ratio < 4 and
        accel_ratio < 4
    )
    print("VERDICT:", "init looks healthy" if ok
          else "INIT IS UNHEALTHY - fix before trusting a full run")
    print("=" * 70)

    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
