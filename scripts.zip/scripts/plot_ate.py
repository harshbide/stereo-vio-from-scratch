r"""
Plot VIO estimated trajectory vs EuRoC ground truth.

Usage (PowerShell):
    python scripts\plot_ate.py --dataset "$env:MAV0" --traj traj_120s_w12.csv
    python scripts\plot_ate.py --dataset "$env:MAV0" --traj traj_120s_w12.csv --save ate_plot.png --no-show

Panels:
  1. XY top view, RAW (unaligned)   -> shows the frame offset (your 4.17 m raw error)
  2. XY top view, SE(3)-aligned     -> shows the actual tracking quality
  3. Position error vs time (after SE(3) alignment)
"""
import argparse
import os

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def to_seconds(t):
    """Timestamps may be ns (EuRoC), us, or s. Return seconds."""
    t = np.asarray(t, dtype=float)
    m = np.nanmedian(np.abs(t))
    if m > 1e15:
        return t * 1e-9
    if m > 1e12:
        return t * 1e-6
    return t


def load_groundtruth(dataset):
    path = os.path.join(dataset, "state_groundtruth_estimate0", "data.csv")
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    t = to_seconds(df["#timestamp"].values)
    p = df[["p_RS_R_x [m]", "p_RS_R_y [m]", "p_RS_R_z [m]"]].values
    return t, p


def load_estimate(path):
    """Handles CSV with/without header, comma/space separated, '#' comments (TUM style)."""
    df = pd.read_csv(path, sep=None, engine="python", comment="#", header=None)
    # If first row is a header (non-numeric), re-read with header
    first = pd.to_numeric(df.iloc[0], errors="coerce")
    if first.isna().any():
        df = pd.read_csv(path, sep=None, engine="python", comment="#")
        cols = [str(c).strip().lower().lstrip("#").strip() for c in df.columns]
        df.columns = cols

        def find(*names):
            for n in names:
                for c in cols:
                    if c == n or c.startswith(n + " ") or c.startswith(n + "["):
                        return c
            return None

        tc = find("timestamp", "time", "t", "ts")
        xc = find("x", "p_x", "px", "tx")
        yc = find("y", "p_y", "py", "ty")
        zc = find("z", "p_z", "pz", "tz")
        if None in (tc, xc, yc, zc):
            # fall back to first 4 columns
            tc, xc, yc, zc = cols[:4]
        t = to_seconds(df[tc].values)
        p = df[[xc, yc, zc]].values.astype(float)
    else:
        df = df.apply(pd.to_numeric, errors="coerce")
        t = to_seconds(df.iloc[:, 0].values)
        p = df.iloc[:, 1:4].values.astype(float)  # TUM / simple: t x y z ...
    return t, p


def umeyama_se3(src, dst):
    """Rigid transform (R, t) minimising ||R*src + t - dst||, no scale."""
    mu_s, mu_d = src.mean(0), dst.mean(0)
    S, D = src - mu_s, dst - mu_d
    U, _, Vt = np.linalg.svd(D.T @ S / len(src))
    E = np.eye(3)
    if np.linalg.det(U) * np.linalg.det(Vt) < 0:
        E[2, 2] = -1
    R = U @ E @ Vt
    t = mu_d - R @ mu_s
    return R, t


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, help="path to EuRoC mav0 folder")
    ap.add_argument("--traj", required=True, help="estimated trajectory file")
    ap.add_argument("--save", default="ate_plot.png", help="output image path")
    ap.add_argument("--no-show", action="store_true", help="save only, no window")
    ap.add_argument("--max-dt", type=float, default=0.01, help="max time gap to GT [s]")
    args = ap.parse_args()

    t_gt, p_gt = load_groundtruth(args.dataset)
    t_est, p_est = load_estimate(args.traj)

    # Keep estimates that fall inside the GT time range, interpolate GT at those times
    ok = (t_est >= t_gt[0]) & (t_est <= t_gt[-1])
    idx = np.clip(np.searchsorted(t_gt, t_est), 1, len(t_gt) - 1)
    near = np.minimum(np.abs(t_gt[idx] - t_est), np.abs(t_gt[idx - 1] - t_est))
    ok &= near <= args.max_dt
    t_est, p_est = t_est[ok], p_est[ok]
    p_ref = np.column_stack([np.interp(t_est, t_gt, p_gt[:, i]) for i in range(3)])

    R, t = umeyama_se3(p_est, p_ref)
    p_al = (R @ p_est.T).T + t
    err = np.linalg.norm(p_al - p_ref, axis=1)
    raw_err = np.linalg.norm(p_est - p_ref, axis=1)

    rmse = np.sqrt(np.mean(err ** 2))
    print(f"Matched poses : {len(err)}")
    print(f"Raw RMSE      : {np.sqrt(np.mean(raw_err ** 2)):.4f} m")
    print(f"SE(3) RMSE    : {rmse:.4f} m   (max {err.max():.4f} m)")

    tt = t_est - t_est[0]
    fig, ax = plt.subplots(1, 3, figsize=(18, 5.5), dpi=120)

    ax[0].plot(p_gt[:, 0], p_gt[:, 1], color="0.75", lw=1, label="GT (full)")
    ax[0].plot(p_ref[:, 0], p_ref[:, 1], "k-", lw=1.5, label="Ground truth")
    ax[0].plot(p_est[:, 0], p_est[:, 1], "r-", lw=1.5, label="Estimate (raw)")
    ax[0].set_title(f"XY - raw (unaligned), RMSE {np.sqrt(np.mean(raw_err**2)):.2f} m")

    ax[1].plot(p_ref[:, 0], p_ref[:, 1], "k-", lw=1.5, label="Ground truth")
    ax[1].plot(p_al[:, 0], p_al[:, 1], "r-", lw=1.5, label="Estimate (SE(3) aligned)")
    ax[1].plot(p_ref[0, 0], p_ref[0, 1], "go", ms=8, label="Start")
    ax[1].plot(p_ref[-1, 0], p_ref[-1, 1], "bX", ms=8, label="End")
    ax[1].set_title(f"XY - SE(3) aligned, RMSE {rmse:.3f} m")

    for a in ax[:2]:
        a.set_xlabel("x [m]")
        a.set_ylabel("y [m]")
        a.set_aspect("equal", adjustable="datalim")
        a.grid(alpha=0.3)
        a.legend(loc="best", fontsize=8)

    ax[2].plot(tt, err, "r-", lw=1.2)
    ax[2].axhline(rmse, color="k", ls="--", lw=1, label=f"RMSE {rmse:.3f} m")
    ax[2].set_xlabel("time [s]")
    ax[2].set_ylabel("position error [m]")
    ax[2].set_title("ATE over time (SE(3) aligned)")
    ax[2].grid(alpha=0.3)
    ax[2].legend()

    fig.tight_layout()
    fig.savefig(args.save)
    print(f"Saved: {args.save}")
    if not args.no_show:
        plt.show()


if __name__ == "__main__":
    main()