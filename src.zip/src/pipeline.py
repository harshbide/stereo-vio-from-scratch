import numpy as np

from state import NavState
from dataset import EuRoCDataset
from imu_preintegration import ImuPreintegrator
from vo_frontend import (
    StereoVOFrontend,
    cam_rel_to_body_rel
)
from factors import (
    imu_factor,
    vo_factor,
    zupt_factor
)
from optimizer import optimize_keyframe
from smoother import optimize_window


class VioPipeline:

    def __init__(
        self,
        sequence_dir,
        keyframe_stride=2,
        max_keyframes=None,
        verbose=False,
        window_size=5,
        use_zupt=True
    ):

        self.ds = EuRoCDataset(
            sequence_dir
        )

        self.frontend = StereoVOFrontend(
            self.ds
        )

        self.keyframe_stride = keyframe_stride
        self.max_keyframes = max_keyframes
        self.verbose = verbose

        # window_size=1 reproduces the original one-step filter exactly
        # (each new node is solved once against a fixed predecessor and
        # immediately frozen). window_size>1 keeps the last N nodes
        # jointly optimizable via smoother.optimize_window, so a bias
        # or attitude error picked up a few keyframes ago can still be
        # corrected by evidence (VO/IMU factors) that arrives later,
        # instead of being permanently locked in the moment it's first
        # estimated.
        self.window_size = max(1, window_size)

        # ZUPT is a strong constraint; expose it so it can be disabled
        # if a sequence genuinely never sits still.
        self.use_zupt = use_zupt

        self.R_body_cam0 = (
            self.ds.cam0_calib.R_body_cam
        )

        self.t_body_cam0 = (
            self.ds.cam0_calib.t_body_cam
        )

        self.trajectory = []
        self.gt_trajectory = []

    # ------------------------------------------------------------------

    def _init_state(self):

        # IMPORTANT:
        #
        # Do NOT read state_groundtruth_estimate0 here.
        #
        # The estimator is initialized only from the actual IMU.
        #
        R0, bg0, ba0, t0_ns = (
            self.ds.initialize_from_imu(
                duration_s=0.5
            )
        )

        return NavState(
            R=R0,
            v=np.zeros(3),
            p=np.zeros(3),
            bg=bg0,
            ba=ba0,
            t=t0_ns * 1e-9
        )

    # ------------------------------------------------------------------

    @staticmethod
    def _is_stationary(imu_rows, gyro_std_max=0.02, acc_std_max=0.35,
                       acc_norm_tol=0.60, gravity_mag=9.81007):
        """Conservative stationarity test over one keyframe interval.

        IMPORTANT: this tests raw (uncalibrated) IMU data. A static
        platform does NOT read ~0 rad/s on the gyro -- it reads
        approximately the (nonzero, often ~0.01-0.1 rad/s for this
        sensor) bias. So the gate must be on gyro VARIANCE (does the
        reading stay constant, i.e. no rotation) rather than gyro
        MAGNITUDE (which a mean-based test would wrongly reject on
        every real interval, static or not, once bias is nonzero).

        Requires all three of: low gyro variance, low accelerometer
        variance, and mean accelerometer magnitude close to gravity.
        All three must hold simultaneously -- any single one alone is
        easy to satisfy while moving (e.g. constant velocity gives low
        accel variance too), and a false positive injects a hard v=0
        constraint into a moving segment, which is worse than no ZUPT
        at all.
        """
        if imu_rows is None or len(imu_rows) < 3:
            return False

        rows = np.asarray(imu_rows, dtype=np.float64)
        gyro = rows[:, 1:4]
        accel = rows[:, 4:7]

        gyro_std = float(np.max(np.std(gyro, axis=0)))
        acc_std = float(np.max(np.std(accel, axis=0)))
        acc_norm = float(np.linalg.norm(np.mean(accel, axis=0)))

        return (
            gyro_std <= gyro_std_max and
            acc_std <= acc_std_max and
            abs(acc_norm - gravity_mag) <= acc_norm_tol
        )

    def run(self):

        ts = (
            self.ds
            .keyframe_timestamps(
                self.keyframe_stride
            )
        )

        if self.max_keyframes is not None:
            ts = ts[
                :self.max_keyframes
            ]

        if len(ts) < 2:
            raise RuntimeError(
                "Need at least two keyframes."
            )

        # ==============================================================
        # INITIAL STATE
        # ==============================================================
        #
        # `window` holds the last (up to) window_size keyframe states,
        # still jointly optimizable. `window_gt` mirrors it 1:1 for
        # evaluation/plotting. `edge_factor_fns[e]` is the list of
        # factor closures tying window[e] -> window[e+1]. Nodes are
        # only moved into the permanent self.trajectory/self.gt_trajectory
        # once they age out of the window (or at the very end, when
        # whatever's left is flushed) -- at that point they are frozen
        # and never revisited, same as the single-step filter always was.

        window = [self._init_state()]
        window_gt = [
            self.ds.groundtruth_pose_near(int(ts[0]))
        ]
        edge_factor_fns = []

        # Prime stereo VO.
        t_ns0, img0_0, img1_0 = (
            self.ds.stereo_pair_at(
                int(ts[0])
            )
        )

        self.frontend.process_keyframe(
            img0_0,
            img1_0
        )

        prev_t_ns = t_ns0
        n_zupt_applied = 0

        # ==============================================================
        # KEYFRAME LOOP
        # ==============================================================

        for k, t_target in enumerate(
            ts[1:],
            start=1
        ):

            t_ns, img0, img1 = (
                self.ds.stereo_pair_at(
                    int(t_target)
                )
            )

            prev_state = window[-1]

            # ==========================================================
            # IMU PREINTEGRATION
            # ==========================================================

            imu_rows = self.ds.imu_between(
                prev_t_ns,
                t_ns
            )

            preint = ImuPreintegrator(
                bg0=prev_state.bg.copy(),
                ba0=prev_state.ba.copy()
            )

            if len(imu_rows) == 0:

                if self.verbose:
                    print(
                        f"[keyframe {k}] "
                        "no IMU samples"
                    )

                state_j_init = (
                    prev_state.copy()
                )

            else:

                # Integrate from the previous
                # camera timestamp to the current
                # camera timestamp.

                prev_sample_t_ns = (
                    prev_t_ns
                )

                for row in imu_rows:

                    t_sample = int(
                        row[0]
                    )

                    dt = (
                        t_sample -
                        prev_sample_t_ns
                    ) * 1e-9

                    if dt > 0:

                        omega = np.array(
                            row[1:4],
                            dtype=np.float64
                        )

                        accel = np.array(
                            row[4:7],
                            dtype=np.float64
                        )

                        preint.integrate(
                            omega,
                            accel,
                            dt
                        )

                    prev_sample_t_ns = (
                        t_sample
                    )

                # IMPORTANT:
                #
                # Integrate the final fraction between
                # the last IMU measurement and camera
                # timestamp instead of dropping it.

                tail_dt = (
                    t_ns -
                    prev_sample_t_ns
                ) * 1e-9

                if tail_dt > 0:

                    last = imu_rows[-1]

                    preint.integrate(
                        np.asarray(
                            last[1:4],
                            dtype=np.float64
                        ),
                        np.asarray(
                            last[4:7],
                            dtype=np.float64
                        ),
                        tail_dt
                    )

                state_j_init = (
                    preint.predict(
                        prev_state
                    )
                )

            # ==========================================================
            # VISUAL ODOMETRY
            # ==========================================================

            (
                R_rel_cam,
                t_rel_cam,
                n_inliers
            ) = self.frontend.process_keyframe(
                img0,
                img1
            )

            # Always retain IMU factor.
            factor_fns = [
                lambda si, sj, pr=preint:
                    imu_factor(
                        si,
                        sj,
                        pr
                    )
            ]

            # Add visual factor only when visual tracking succeeded
            # AND it is roughly consistent with what the IMU predicts.
            #
            # vo_frontend only screens out completely degenerate PnP
            # solves (see its own comment); a solve can still pass
            # that check yet disagree wildly with the IMU-integrated
            # motion (e.g. a near-planar point configuration or a
            # partial mismatch in the tracked correspondences). Even
            # with the sliding window able to revise recent nodes,
            # it's still worth screening a badly-disagreeing VO factor
            # out before it ever enters the graph.
            if R_rel_cam is not None:

                (
                    R_rel_body,
                    t_rel_body
                ) = cam_rel_to_body_rel(
                    R_rel_cam,
                    t_rel_cam,
                    self.R_body_cam0,
                    self.t_body_cam0
                )

                imu_rel_p_body = (
                    prev_state.R.T @
                    (state_j_init.p - prev_state.p)
                )

                disagreement = np.linalg.norm(
                    t_rel_body - imu_rel_p_body
                )

                # Absolute floor covers slow/near-stationary motion
                # (where the IMU prediction itself is ~0 and any fixed
                # relative tolerance would be meaninglessly tight);
                # the relative term scales the tolerance up for
                # genuinely fast segments instead of using one
                # constant that's either too loose or too tight
                # everywhere.
                tol = max(
                    0.20,
                    0.5 * np.linalg.norm(imu_rel_p_body)
                )

                if disagreement <= tol:

                    factor_fns.append(
                        lambda si, sj, R=R_rel_body, t=t_rel_body, n=n_inliers:
                            vo_factor(
                                si,
                                sj,
                                R,
                                t,
                                n_inliers=n
                            )
                    )

                elif self.verbose:

                    print(
                        f"[keyframe {k}] "
                        f"VO/IMU disagreement {disagreement:.3f} m "
                        f"(tol {tol:.3f} m); dropping VO factor"
                    )

            elif self.verbose:

                print(
                    f"[keyframe {k}] "
                    "VO failed; using IMU prediction"
                )

            # ==========================================================
            # ZERO-VELOCITY UPDATE
            # ==========================================================
            #
            # The one absolute constraint available here. Relative
            # IMU/VO factors cannot observe a slowly accumulating
            # velocity error; asserting v=0 while genuinely static
            # cancels it outright and bounds the quadratic position
            # drift that otherwise dominates long sequences.

            if self.use_zupt and self._is_stationary(imu_rows):

                factor_fns.append(
                    lambda si, sj: zupt_factor(si, sj)
                )
                n_zupt_applied += 1

                if self.verbose:
                    print(f"[keyframe {k}] ZUPT applied")

            # ==========================================================
            # WINDOWED OPTIMIZATION
            # ==========================================================

            state_j_init.t = t_ns * 1e-9

            window.append(state_j_init)
            window_gt.append(
                self.ds.groundtruth_pose_near(t_ns)
            )
            edge_factor_fns.append(factor_fns)

            if self.window_size <= 1:
                # Degenerates to the original one-step filter: solve
                # this single edge against a fixed predecessor.
                window[-1] = optimize_keyframe(
                    window[-2],
                    window[-1],
                    factor_fns,
                    max_iters=8,
                    verbose=False
                )
            else:
                factor_specs = [
                    (e, e + 1, fn)
                    for e, fns in enumerate(edge_factor_fns)
                    for fn in fns
                ]
                window = optimize_window(
                    window,
                    factor_specs,
                    fixed_idx=(0,),
                    max_iters=8,
                    verbose=False
                )

            window[-1].t = t_ns * 1e-9

            if self.verbose:

                print(
                    f"[keyframe {k}] "
                    f"t={window[-1].t:.3f}s "
                    f"p={np.round(window[-1].p, 3)} "
                    f"vo_inliers={n_inliers}"
                )

            # Age the oldest node out of the window once it's full;
            # its current (just re-optimized) estimate is now frozen.
            while len(window) > self.window_size:
                self.trajectory.append(window.pop(0))
                self.gt_trajectory.append(window_gt.pop(0))
                edge_factor_fns.pop(0)

            prev_t_ns = t_ns

        # Flush whatever's left in the window at the end of the run.
        self.trajectory.extend(window)
        self.gt_trajectory.extend(window_gt)

        self.n_zupt_applied = n_zupt_applied
        print(
            f"[pipeline] ZUPT applied on {n_zupt_applied} / "
            f"{len(ts) - 1} keyframe intervals"
        )

        return self.trajectory