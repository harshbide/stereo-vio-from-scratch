import numpy as np

from state import STATE_DIM

# Per-block tangent-space step limits, in the natural units of each
# block (rad, m/s, m, rad/s, m/s^2). A single combined norm cap (as the
# previous version used) lets a bad factor spend its whole "budget" on
# position alone -- e.g. a norm cap of 2.0 permitted a ~2 m position
# jump in a *single* GN iteration, repeated for up to max_iters
# iterations, which is how one corrupted VO measurement could inject
# several meters of error into a single keyframe.
STEP_LIMITS = np.array(
    [0.2, 0.2, 0.2,      # delta rotation (rad)
     1.0, 1.0, 1.0,      # delta velocity (m/s)
     0.3, 0.3, 0.3,      # delta position (m)
     0.05, 0.05, 0.05,   # delta gyro bias (rad/s)
     0.05, 0.05, 0.05],  # delta accel bias (m/s^2)
    dtype=np.float64
)


def evaluate_cost(state_i, state_j, factor_fns):
    """Sum of r^T W r over all factors, at the given linearization
    point. Used both inside gauss_newton_step and to check whether a
    proposed step actually improved things."""
    cost = 0.0
    for fn in factor_fns:
        r, J, W = fn(state_i, state_j)
        if not (np.isfinite(r).all() and np.isfinite(W).all()):
            continue
        cost += float(r.T @ W @ r)
    return cost


def gauss_newton_step(
    state_i,
    state_j,
    factor_fns,
    lam=1e-4
):
    """One linearize-and-solve step. Returns the *candidate* next
    state along with the cost at state_j (before the step) and the
    cost at the candidate (after the step), so the caller can decide
    whether to accept it (Levenberg-Marquardt style) rather than
    blindly taking every step."""

    H = np.zeros((STATE_DIM, STATE_DIM), dtype=np.float64)
    b = np.zeros(STATE_DIM, dtype=np.float64)
    cost = 0.0

    for fn in factor_fns:

        r, J, W = fn(state_i, state_j)

        # Numerical safety.
        if not (
            np.isfinite(r).all() and
            np.isfinite(J).all() and
            np.isfinite(W).all()
        ):
            continue

        H += J.T @ W @ J
        b += J.T @ W @ r
        cost += float(r.T @ W @ r)

    # Symmetrize.
    H = 0.5 * (H + H.T)

    # Levenberg-Marquardt damping. `lam` is adapted by the caller
    # based on whether steps are being accepted or rejected -- a fixed
    # 1e-6 factor (the previous version) is negligible next to typical
    # H diagonal entries and provides essentially no regularization.
    diagonal = np.maximum(np.diag(H), 1e-12)
    damping = lam * np.maximum(diagonal, 1.0)
    H_damped = H + np.diag(damping)

    try:
        dx = np.linalg.solve(H_damped, -b)
    except np.linalg.LinAlgError:
        dx = np.linalg.lstsq(H_damped, -b, rcond=None)[0]

    dx_norm = np.linalg.norm(dx)

    if not np.isfinite(dx_norm):
        return state_j, cost, np.inf, np.inf

    # Per-block safety limits instead of one combined norm cap.
    ratios = np.abs(dx) / STEP_LIMITS
    worst = np.max(ratios)
    if worst > 1.0:
        dx = dx / worst
        dx_norm = np.linalg.norm(dx)

    candidate_state_j = state_j.boxplus(dx)
    new_cost = evaluate_cost(state_i, candidate_state_j, factor_fns)

    return candidate_state_j, cost, new_cost, dx_norm


def optimize_keyframe(
    state_i,
    state_j_init,
    factor_fns,
    max_iters=8,
    dx_tol=1e-7,
    verbose=False
):
    """Damped Gauss-Newton (Levenberg-Marquardt) with step acceptance:
    a proposed step is only taken if it does not increase the total
    cost. If it does, the step is rejected, the damping is increased,
    and the solve is retried from the same linearization point. This
    prevents a single bad/outlier factor (e.g. a corrupted VO
    measurement) from making the estimate *worse* -- the previous
    version always accepted the step regardless of whether the cost
    went up or down, which let bad iterations actively diverge."""

    state_j = state_j_init.copy()
    lam = 1e-4
    cur_cost = evaluate_cost(state_i, state_j, factor_fns)

    for it in range(max_iters):

        tries = 0
        accepted = False

        while tries < 5:

            (
                candidate,
                cost_before,
                new_cost,
                step_norm
            ) = gauss_newton_step(
                state_i,
                state_j,
                factor_fns,
                lam=lam
            )

            if not np.isfinite(new_cost):
                lam = min(lam * 10.0, 1e6)
                tries += 1
                continue

            if new_cost <= cost_before + 1e-12:
                # Improvement (or no change) -- accept the step and
                # relax the damping for the next iteration.
                state_j = candidate
                cur_cost = new_cost
                lam = max(lam * 0.3, 1e-8)
                accepted = True
                break
            else:
                # Step made things worse -- reject it, damp harder,
                # and retry from the same state_j.
                lam = min(lam * 10.0, 1e6)
                tries += 1

        if verbose:
            print(
                f"GN {it}: cost={cur_cost:.6e}, "
                f"|dx|={step_norm:.6e}, "
                f"accepted={accepted}, lam={lam:.2e}"
            )

        if not accepted:
            # Could not find any improving step even with heavy
            # damping -- stop rather than keep perturbing the state.
            break

        if step_norm < dx_tol:
            break

    return state_j