"""
Minimal SO(3) Lie group utilities used throughout the VIO backend.

No external dependency beyond numpy -- this replaces the small slice of
GTSAM's Rot3 / SO3 functionality that this project needs:
    - hat / vee  (so(3) <-> R^3)
    - Exp / Log  (so(3) tangent <-> SO(3) group)
    - right Jacobian of SO(3) (needed for IMU bias-Jacobian propagation)
"""

import numpy as np

_EPS = 1e-8


def hat(w: np.ndarray) -> np.ndarray:
    """R^3 -> so(3) skew-symmetric matrix."""
    wx, wy, wz = w
    return np.array([
        [0.0, -wz,  wy],
        [wz,  0.0, -wx],
        [-wy,  wx, 0.0],
    ])


def vee(W: np.ndarray) -> np.ndarray:
    """so(3) skew-symmetric matrix -> R^3."""
    return np.array([W[2, 1], W[0, 2], W[1, 0]])


def Exp(phi: np.ndarray) -> np.ndarray:
    """so(3) tangent vector -> SO(3) rotation matrix (Rodrigues formula)."""
    theta = np.linalg.norm(phi)
    if theta < _EPS:
        return np.eye(3) + hat(phi)
    axis = phi / theta
    K = hat(axis)
    return (np.eye(3)
            + np.sin(theta) * K
            + (1.0 - np.cos(theta)) * (K @ K))


def Log(R: np.ndarray) -> np.ndarray:
    """SO(3) rotation matrix -> so(3) tangent vector."""
    cos_theta = np.clip((np.trace(R) - 1.0) / 2.0, -1.0, 1.0)
    theta = np.arccos(cos_theta)
    if theta < _EPS:
        return vee(R - R.T) / 2.0
    return vee(R - R.T) * (theta / (2.0 * np.sin(theta)))


def right_jacobian(phi: np.ndarray) -> np.ndarray:
    """Right Jacobian Jr(phi) of SO(3), used to propagate bias Jacobians
    through IMU preintegration (Forster et al., 2015, eq. 40-41)."""
    theta = np.linalg.norm(phi)
    if theta < _EPS:
        return np.eye(3) - 0.5 * hat(phi)
    axis = phi / theta
    K = hat(axis)
    return (np.eye(3)
            - (1 - np.cos(theta)) / theta * K
            + (theta - np.sin(theta)) / theta * (K @ K))


def right_jacobian_inv(phi: np.ndarray) -> np.ndarray:
    """Inverse right Jacobian Jr^{-1}(phi)."""
    theta = np.linalg.norm(phi)
    if theta < _EPS:
        return np.eye(3) + 0.5 * hat(phi)
    axis = phi / theta
    K = hat(axis)
    cot_half = 1.0 / np.tan(theta / 2.0)
    return (np.eye(3)
            + 0.5 * hat(phi)
            + (1.0 / theta ** 2 - (1 + np.cos(theta)) / (2 * theta * np.sin(theta))) * (theta ** 2) * (K @ K))


def normalize_rotation(R: np.ndarray) -> np.ndarray:
    """Re-orthonormalize a rotation matrix that has drifted numerically."""
    U, _, Vt = np.linalg.svd(R)
    Rn = U @ Vt
    if np.linalg.det(Rn) < 0:
        U[:, -1] *= -1
        Rn = U @ Vt
    return Rn
