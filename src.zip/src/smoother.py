"""
Fixed-lag sliding-window smoother.

The original optimizer (optimizer.py) only ever solves for a single
state_j given a *fixed* state_i (a one-step filter): once a keyframe's
state is committed, nothing about it can ever be revised, so any error
picked up while estimating it (e.g. a slightly-wrong bias) is
permanent. This module jointly re-optimizes the last `window_size`
keyframe states together every time a new keyframe arrives, using the
same per-factor residual/Jacobian/weight functions from factors.py.
Only the oldest state in the window is held fixed (a simplified
"anchor" in place of a full marginalization prior) -- everything else
in the window is free.

Each factor function (imu_factor, vo_factor) only returns the Jacobian
with respect to its *second* argument (state_j), because that's all
the original single-step optimizer needed (state_i was always fixed
there). For interior window nodes, state_i is *not* fixed anymore, so
we also need dr/d(state_i). Deriving that in closed form for every
factor is easy to get subtly wrong without a dataset to validate
against, so instead it's computed here with a central-difference
numerical Jacobian -- slower than analytic, but its correctness is
easy to check independently (see the smoke test), and window sizes /
factor counts here are small enough that the extra cost is negligible
next to feature tracking and PnP.
"""

import numpy as np

from state import STATE_DIM

STEP_LIMITS = np.array(
    [0.2, 0.2, 0.2,
     1.0, 1.0, 1.0,
     0.3, 0.3, 0.3,
     0.05, 0.05, 0.05,
     0.05, 0.05, 0.05],
    dtype=np.float64
)


def numerical_jacobian_wrt_i(factor_fn, state_i, state_j, eps=1e-6):
    """Central-difference Jacobian of factor_fn's residual with
    respect to state_i's 15-dim tangent space, holding state_j fixed."""
    r0, _, _ = factor_fn(state_i, state_j)
    dim_r = r0.shape[0]
    J = np.zeros((dim_r, STATE_DIM))
    for k in range(STATE_DIM):
        dx = np.zeros(STATE_DIM)
        dx[k] = eps
        r_plus, _, _ = factor_fn(state_i.boxplus(dx), state_j)
        dx[k] = -eps
        r_minus, _, _ = factor_fn(state_i.boxplus(dx), state_j)
        J[:, k] = (r_plus - r_minus) / (2 * eps)
    return J


def _evaluate_total_cost(states, factor_specs):
    cost = 0.0
    for i_idx, j_idx, fn in factor_specs:
        r, _, W = fn(states[i_idx], states[j_idx])
        if not (np.isfinite(r).all() and np.isfinite(W).all()):
            continue
        cost += float(r.T @ W @ r)
    return cost


def _linearize(states, factor_specs, free_idx):
    """free_idx: sorted list of node indices that are NOT fixed. Builds
    the joint (dense) Hessian/gradient over just those nodes."""
    n_free = len(free_idx)
    pos = {idx: k for k, idx in enumerate(free_idx)}

    H = np.zeros((n_free * STATE_DIM, n_free * STATE_DIM))
    b = np.zeros(n_free * STATE_DIM)
    cost = 0.0

    for i_idx, j_idx, fn in factor_specs:

        r, J_j, W = fn(states[i_idx], states[j_idx])

        if not (np.isfinite(r).all() and np.isfinite(J_j).all()
                and np.isfinite(W).all()):
            continue

        cost += float(r.T @ W @ r)

        i_free = i_idx in pos
        j_free = j_idx in pos

        if j_free:
            jj = pos[j_idx]
            sl_j = slice(jj * STATE_DIM, (jj + 1) * STATE_DIM)
            H[sl_j, sl_j] += J_j.T @ W @ J_j
            b[sl_j] += J_j.T @ W @ r

        if i_free:
            J_i = numerical_jacobian_wrt_i(fn, states[i_idx], states[j_idx])
            ii = pos[i_idx]
            sl_i = slice(ii * STATE_DIM, (ii + 1) * STATE_DIM)
            H[sl_i, sl_i] += J_i.T @ W @ J_i
            b[sl_i] += J_i.T @ W @ r

            if j_free:
                sl_j = slice(pos[j_idx] * STATE_DIM, (pos[j_idx] + 1) * STATE_DIM)
                cross = J_i.T @ W @ J_j
                H[sl_i, sl_j] += cross
                H[sl_j, sl_i] += cross.T

    return H, b, cost


def optimize_window(
    states,
    factor_specs,
    fixed_idx=(0,),
    max_iters=8,
    dx_tol=1e-7,
    verbose=False
):
    """
    states: list of NavState, index 0 = oldest .. -1 = newest.
    factor_specs: list of (i_idx, j_idx, factor_fn) with i_idx < j_idx,
        factor_fn(state_i, state_j) -> (residual, J_wrt_j, W) matching
        the signatures in factors.py.
    fixed_idx: node indices held fixed (typically just the oldest,
        acting as a simplified anchor in place of a marginalization
        prior -- correlations with states dropped off the back of the
        window are not otherwise accounted for).

    Returns a new list of states (same length), with all non-fixed
    entries updated in place (copies), and reports the number of GN
    iterations actually taken via the 'iterations' key isn't returned
    -- callers that want diagnostics should pass verbose=True.
    """

    states = [s.copy() for s in states]
    free_idx = [i for i in range(len(states)) if i not in fixed_idx]

    if not free_idx:
        return states

    lam = 1e-4
    cur_cost = _evaluate_total_cost(states, factor_specs)

    for it in range(max_iters):

        H, b, cost_before = _linearize(states, factor_specs, free_idx)
        H = 0.5 * (H + H.T)

        tries = 0
        accepted = False
        step_norm = 0.0

        while tries < 5:

            diagonal = np.maximum(np.diag(H), 1e-12)
            damping = lam * np.maximum(diagonal, 1.0)
            H_damped = H + np.diag(damping)

            try:
                dx = np.linalg.solve(H_damped, -b)
            except np.linalg.LinAlgError:
                dx = np.linalg.lstsq(H_damped, -b, rcond=None)[0]

            if not np.isfinite(dx).all():
                lam = min(lam * 10.0, 1e6)
                tries += 1
                continue

            # Per-node, per-block step limits.
            dx_blocks = dx.reshape(len(free_idx), STATE_DIM)
            ratios = np.abs(dx_blocks) / STEP_LIMITS
            worst = np.max(ratios)
            if worst > 1.0:
                dx_blocks = dx_blocks / worst
            step_norm = np.linalg.norm(dx_blocks)

            candidate = [s.copy() for s in states]
            for k, idx in enumerate(free_idx):
                candidate[idx] = states[idx].boxplus(dx_blocks[k])

            new_cost = _evaluate_total_cost(candidate, factor_specs)

            if not np.isfinite(new_cost):
                lam = min(lam * 10.0, 1e6)
                tries += 1
                continue

            if new_cost <= cost_before + 1e-12:
                states = candidate
                cur_cost = new_cost
                lam = max(lam * 0.3, 1e-8)
                accepted = True
                break
            else:
                lam = min(lam * 10.0, 1e6)
                tries += 1

        if verbose:
            print(
                f"window GN {it}: cost={cur_cost:.6e}, "
                f"|dx|={step_norm:.6e}, accepted={accepted}, lam={lam:.2e}"
            )

        if not accepted:
            break
        if step_norm < dx_tol:
            break

    return states
