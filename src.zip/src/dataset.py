"""
EuRoC MAV dataset loader.
"""

import os
import numpy as np
import pandas as pd
import yaml


class CameraCalib:
    def __init__(self, sensor_yaml_path: str):
        with open(sensor_yaml_path, "r") as f:
            y = yaml.safe_load(f)

        fx, fy, cx, cy = y["intrinsics"]

        self.K = np.array([
            [fx, 0.0, cx],
            [0.0, fy, cy],
            [0.0, 0.0, 1.0]
        ], dtype=np.float64)

        self.dist = np.array(
            y.get("distortion_coefficients", [0, 0, 0, 0]),
            dtype=np.float64
        )

        self.dist_model = y.get("distortion_model", "radtan")
        self.resolution = tuple(y.get("resolution", [752, 480]))

        T = np.array(
            y["T_BS"]["data"],
            dtype=np.float64
        ).reshape(4, 4)

        self.T_body_cam = T
        self.R_body_cam = T[:3, :3]
        self.t_body_cam = T[:3, 3]


class EuRoCDataset:
    def __init__(self, sequence_dir: str):

        self.root = sequence_dir
        self.mav0 = os.path.join(sequence_dir, "mav0")

        if not os.path.isdir(self.mav0):
            raise FileNotFoundError(
                f"Expected '{self.mav0}' to exist."
            )

        self.cam0_calib = CameraCalib(
            os.path.join(self.mav0, "cam0", "sensor.yaml")
        )

        self.cam1_calib = CameraCalib(
            os.path.join(self.mav0, "cam1", "sensor.yaml")
        )

        self.cam0_df = self._read_cam_csv("cam0")
        self.cam1_df = self._read_cam_csv("cam1")
        self.imu_df = self._read_imu_csv()
        self.gt_df = self._read_gt_csv()

        # T_BC0 and T_BC1
        T_body_cam0 = self.cam0_calib.T_body_cam
        T_body_cam1 = self.cam1_calib.T_body_cam

        # T_C0C1
        self.T_cam0_cam1 = (
            np.linalg.inv(T_body_cam0) @ T_body_cam1
        )

        self.R_cam0_cam1 = self.T_cam0_cam1[:3, :3]
        self.t_cam0_cam1 = self.T_cam0_cam1[:3, 3]

        self.baseline_m = np.linalg.norm(
            self.t_cam0_cam1
        )

    # ------------------------------------------------------------------
    # CSV
    # ------------------------------------------------------------------

    def _read_cam_csv(self, cam_name):

        path = os.path.join(
            self.mav0,
            cam_name,
            "data.csv"
        )

        df = pd.read_csv(path)
        df.columns = [c.strip() for c in df.columns]

        df = df.rename(
            columns={
                df.columns[0]: "t_ns",
                df.columns[1]: "filename"
            }
        )

        df["t_ns"] = df["t_ns"].astype(np.int64)

        df["path"] = df["filename"].apply(
            lambda f: os.path.join(
                self.mav0,
                cam_name,
                "data",
                f.strip()
            )
        )

        return (
            df.sort_values("t_ns")
            .reset_index(drop=True)
        )

    def _read_imu_csv(self):

        path = os.path.join(
            self.mav0,
            "imu0",
            "data.csv"
        )

        df = pd.read_csv(path)
        df.columns = [c.strip() for c in df.columns]

        df = df.rename(
            columns={
                df.columns[0]: "t_ns",
                df.columns[1]: "wx",
                df.columns[2]: "wy",
                df.columns[3]: "wz",
                df.columns[4]: "ax",
                df.columns[5]: "ay",
                df.columns[6]: "az"
            }
        )

        df["t_ns"] = df["t_ns"].astype(np.int64)

        return (
            df.sort_values("t_ns")
            .reset_index(drop=True)
        )

    def _read_gt_csv(self):

        path = os.path.join(
            self.mav0,
            "state_groundtruth_estimate0",
            "data.csv"
        )

        if not os.path.isfile(path):
            return None

        df = pd.read_csv(path)
        df.columns = [c.strip() for c in df.columns]

        df = df.rename(
            columns={
                df.columns[0]: "t_ns",
                df.columns[1]: "px",
                df.columns[2]: "py",
                df.columns[3]: "pz",
                df.columns[4]: "qw",
                df.columns[5]: "qx",
                df.columns[6]: "qy",
                df.columns[7]: "qz"
            }
        )

        df["t_ns"] = df["t_ns"].astype(np.int64)

        return (
            df.sort_values("t_ns")
            .reset_index(drop=True)
        )

    # ------------------------------------------------------------------
    # IMU
    # ------------------------------------------------------------------

    def imu_between(self, t0_ns, t1_ns):

        mask = (
            (self.imu_df["t_ns"] > t0_ns) &
            (self.imu_df["t_ns"] <= t1_ns)
        )

        sub = self.imu_df.loc[mask]

        return sub[
            [
                "t_ns",
                "wx",
                "wy",
                "wz",
                "ax",
                "ay",
                "az"
            ]
        ].to_numpy()

    # Absolute staticness criteria.
    #
    # IMPORTANT: these operate on RAW (uncalibrated) gyro/accel, which
    # is what's in imu_df. A static platform does NOT read ~0 rad/s on
    # the gyro -- it reads approximately the (unknown, to-be-estimated)
    # bias, which for a real MEMS IMU like the EuRoC ADIS16448 is
    # commonly several *hundredths* of a rad/s and can exceed 0.1
    # rad/s (published EuRoC bias values include e.g.
    # bg=[-0.0023, 0.0249, 0.0817] rad/s). So staticness cannot be
    # "is the mean near zero" -- that would reject every real static
    # window on this sensor. What actually distinguishes static from
    # moving is VARIANCE: a constant (however large) offset has low
    # spread, while genuine rotation changes the reading over time.
    STATIC_GYRO_STD_MAX = 0.02   # rad/s, max per-axis gyro std
    STATIC_ACC_STD_MAX = 0.35    # m/s^2, max per-axis accel std
    STATIC_ACC_NORM_TOL = 0.60   # m/s^2, |mean accel| must be ~= g

    def find_static_window(
        self,
        duration_s=0.5,
        search_s=8.0,
        gravity_mag=9.81007
    ):
        """Search the first `search_s` of IMU data for a window of
        length `duration_s` that is genuinely stationary.

        Scores every candidate window by a combination of mean gyro
        magnitude, accelerometer variance, and how close the mean
        accelerometer magnitude is to gravity -- a truly static IMU
        must satisfy all three simultaneously. Returns the rows of the
        best-scoring window along with a diagnostics dict, or (None,
        diag) if nothing in the search range qualifies.

        This replaces "take the first 0.5 s and hope": the platform is
        frequently still being handled / already flying at t0, and
        every downstream quantity (gyro bias, accel bias, and the
        gravity-aligned initial attitude) is derived from this window
        and then effectively frozen for the entire run.
        """

        cols = ["t_ns", "wx", "wy", "wz", "ax", "ay", "az"]
        t0 = int(self.imu_df["t_ns"].iloc[0])

        sub = self.imu_df.loc[
            self.imu_df["t_ns"] <= t0 + int(search_s * 1e9),
            cols
        ]
        arr = sub.to_numpy(dtype=np.float64)

        if len(arr) < 20:
            return None, {"reason": "too few IMU samples in search range"}

        # Infer sample rate to size the window in samples.
        dts = np.diff(arr[:, 0]) * 1e-9
        dt_med = float(np.median(dts[dts > 0])) if np.any(dts > 0) else 0.005
        n_win = max(20, int(round(duration_s / max(dt_med, 1e-6))))

        if len(arr) < n_win:
            n_win = len(arr)

        best = None
        best_score = np.inf
        candidates = []

        # Slide in steps of ~10% of the window for cheap coverage.
        step = max(1, n_win // 10)

        for s in range(0, len(arr) - n_win + 1, step):
            w = arr[s:s + n_win]
            gyro = w[:, 1:4]
            accel = w[:, 4:7]

            # Variance-based: see STATIC_GYRO_STD_MAX comment above
            # for why this must be spread, not magnitude, of the raw
            # (bias-uncorrected) gyro signal.
            gyro_std = float(np.max(np.std(gyro, axis=0)))
            acc_std = float(np.max(np.std(accel, axis=0)))
            acc_norm = float(np.linalg.norm(np.mean(accel, axis=0)))
            norm_err = abs(acc_norm - gravity_mag)

            candidates.append((gyro_std, acc_std, norm_err))

            qualifies = (
                gyro_std <= self.STATIC_GYRO_STD_MAX and
                acc_std <= self.STATIC_ACC_STD_MAX and
                norm_err <= self.STATIC_ACC_NORM_TOL
            )

            # Normalized score so the three criteria are comparable.
            score = (
                gyro_std / self.STATIC_GYRO_STD_MAX +
                acc_std / self.STATIC_ACC_STD_MAX +
                norm_err / self.STATIC_ACC_NORM_TOL
            )

            if qualifies and score < best_score:
                best_score = score
                best = w

        if best is None:
            # Report the closest miss so the caller can explain *why*.
            arrc = np.array(candidates)
            k = int(np.argmin(arrc.sum(axis=1)))
            return None, {
                "reason": "no static window found",
                "best_gyro_std": float(arrc[k, 0]),
                "best_acc_std": float(arrc[k, 1]),
                "best_acc_norm_err": float(arrc[k, 2]),
                "limits": (
                    self.STATIC_GYRO_STD_MAX,
                    self.STATIC_ACC_STD_MAX,
                    self.STATIC_ACC_NORM_TOL
                ),
            }

        gyro_std = float(np.max(np.std(best[:, 1:4], axis=0)))
        return best, {
            "reason": "ok",
            "n_samples": int(len(best)),
            "t_start_ns": int(best[0, 0]),
            "offset_s": float((best[0, 0] - t0) * 1e-9),
            "gyro_std": gyro_std,
            "gyro_mean_mag": float(np.linalg.norm(np.mean(best[:, 1:4], axis=0))),
            "acc_std": float(np.max(np.std(best[:, 4:7], axis=0))),
            "acc_norm": float(np.linalg.norm(np.mean(best[:, 4:7], axis=0))),
        }

    def initial_imu_window(self, duration_s=0.5, max_duration_s=2.0):
        """Rows used for static initialization.

        Prefers a searched-for genuinely static window; falls back to
        the original "first duration_s" behaviour only if the search
        finds nothing (in which case initialize_from_imu's validation
        will warn loudly rather than proceed silently).
        """

        rows, diag = self.find_static_window(duration_s=duration_s)
        if rows is not None:
            self._static_diag = diag
            return rows

        self._static_diag = diag

        t0 = int(self.imu_df["t_ns"].iloc[0])
        cols = ["t_ns", "wx", "wy", "wz", "ax", "ay", "az"]

        extra_s = duration_s
        sub = self.imu_df.loc[
            self.imu_df["t_ns"] <= t0 + int(extra_s * 1e9), cols
        ]
        while len(sub) < 20 and extra_s < max_duration_s:
            extra_s = min(extra_s * 2.0, max_duration_s)
            sub = self.imu_df.loc[
                self.imu_df["t_ns"] <= t0 + int(extra_s * 1e9), cols
            ]

        if len(sub) < 20:
            raise RuntimeError(
                "Not enough IMU samples for initialization."
            )

        return sub.to_numpy(dtype=np.float64)

    def initialize_from_imu(self, duration_s=0.5):

        rows = self.initial_imu_window(duration_s)

        gyro = rows[:, 1:4]
        accel = rows[:, 4:7]

        # --------------------------------------------------------------
        # Gyroscope bias
        # --------------------------------------------------------------
        #
        # During the initial stationary period, the true angular
        # velocity is approximately zero. Median is used instead of
        # mean so a handful of remaining non-static samples (that
        # passed the coarse MAD gate above but are still somewhat off)
        # don't pull the estimate as much as they would under a mean.
        #
        bg = np.median(gyro, axis=0)

        # --------------------------------------------------------------
        # Average accelerometer measurement
        # --------------------------------------------------------------

        a_mean = np.median(
            accel,
            axis=0
        )

        a_norm = np.linalg.norm(a_mean)

        if a_norm < 1e-6:
            raise RuntimeError(
                "Invalid initial accelerometer measurement."
            )

        # --------------------------------------------------------------
        # Estimate initial roll/pitch from gravity
        # --------------------------------------------------------------

        # EuRoC world gravity.
        gravity = np.array(
            [0.0, 0.0, -9.81007],
            dtype=np.float64
        )

        # The accelerometer measures specific force.
        #
        # When stationary:
        #
        #       a_body = -R^T * g
        #
        # Therefore we want R such that:
        #
        #       R * a_body = -g
        #
        v1 = a_mean / a_norm
        v2 = (-gravity) / np.linalg.norm(gravity)

        # Rodrigues rotation taking v1 -> v2.
        cross = np.cross(v1, v2)
        dot = np.clip(
            np.dot(v1, v2),
            -1.0,
            1.0
        )

        s = np.linalg.norm(cross)

        if s < 1e-10:

            # Vectors are parallel or anti-parallel.
            if dot > 0.0:

                R0 = np.eye(3)

            else:

                # 180-degree rotation around any axis
                # perpendicular to v1.
                axis = np.array(
                    [1.0, 0.0, 0.0]
                )

                if abs(
                        np.dot(axis, v1)
                ) > 0.9:
                    axis = np.array(
                        [0.0, 1.0, 0.0]
                    )

                axis -= (
                        np.dot(axis, v1) *
                        v1
                )

                axis /= np.linalg.norm(axis)

                K = np.array([
                    [0.0, -axis[2], axis[1]],
                    [axis[2], 0.0, -axis[0]],
                    [-axis[1], axis[0], 0.0]
                ])

                R0 = (
                        np.eye(3) +
                        2.0 * K @ K
                )

        else:

            axis = cross / s

            K = np.array([
                [0.0, -axis[2], axis[1]],
                [axis[2], 0.0, -axis[0]],
                [-axis[1], axis[0], 0.0]
            ])

            angle = np.arctan2(
                s,
                dot
            )

            R0 = (
                    np.eye(3) +
                    np.sin(angle) * K +
                    (1.0 - np.cos(angle)) *
                    (K @ K)
            )

        # --------------------------------------------------------------
        # Accelerometer bias
        # --------------------------------------------------------------

        expected_specific_force = (
                R0.T @ (-gravity)
        )

        ba = (
                a_mean -
                expected_specific_force
        )

        # --------------------------------------------------------------
        # Validation
        # --------------------------------------------------------------
        #
        # Every quantity above (bg, ba, and especially the
        # gravity-aligned R0) is computed once and then effectively
        # frozen: the bias random-walk factor pins bias_j to bias_i
        # with a weight ~1e6-1e10, which is orders of magnitude
        # stiffer than any IMU/VO measurement weight (~1e2-1e3), so
        # nothing downstream can pull the bias back toward truth.
        #
        # That makes a bad init silent and fatal rather than merely
        # noisy: a gravity-alignment tilt of only ~0.25 deg leaves a
        # ~0.04 m/s^2 residual specific force, which double-integrates
        # to several hundred metres over a ~140 s sequence while
        # looking perfectly healthy over a 10 s test run. So validate
        # loudly here instead of proceeding.
        #
        # Reference magnitudes for the EuRoC ADIS16448: gyro bias is
        # O(1e-3) rad/s, accel bias O(1e-2) m/s^2.

        diag = getattr(self, "_static_diag", {"reason": "not searched"})
        warnings = []

        if diag.get("reason") != "ok":
            warnings.append(
                "no genuinely static window was found in the first "
                "seconds of the sequence; initialization fell back to "
                f"the first {duration_s}s regardless of motion "
                f"(details: {diag})"
            )

        bg_mag = float(np.linalg.norm(bg))
        ba_mag = float(np.linalg.norm(ba))

        # Reference magnitudes for the EuRoC ADIS16448 (RAW,
        # uncalibrated sensor). Published constant biases for this
        # exact sensor/dataset are on the order of
        # bg ~ [1e-3 .. 1e-1] rad/s, ba ~ [1e-2 .. 1e-1] m/s^2 -- e.g.
        # bg=[-0.0023, 0.0249, 0.0817], ba=[-0.0236, 0.1210, 0.0748]
        # have been reported for a EuRoC sequence, and 0.08 rad/s on
        # one axis is NORMAL, not a sign of a moving window. There is
        # no tight physically-meaningful absolute threshold here (unlike
        # the variance-based staticness test above, which is what
        # actually distinguishes a bad window) -- so this only flags
        # genuinely extreme values that would indicate the window was
        # actively rotating/falling despite passing the variance gate.
        if bg_mag > 0.3:
            warnings.append(
                f"gyro bias magnitude {bg_mag:.5f} rad/s "
                f"({np.degrees(bg_mag):.2f} deg/s) is extreme even for "
                "an uncalibrated MEMS gyro -- double check the window"
            )

        if ba_mag > 1.0:
            warnings.append(
                f"accel bias magnitude {ba_mag:.4f} m/s^2 is extreme "
                "even for an uncalibrated MEMS accelerometer -- double "
                "check the window"
            )

        self.init_warnings = warnings

        if warnings:
            print(
                "\n"
                "!! IMU INITIALIZATION WARNING "
                "-------------------------------------"
            )
            for w in warnings:
                print(f"  - {w}")
            print(
                "  Downstream effect: biases are structurally frozen at\n"
                "  these values, so this error will double-integrate\n"
                "  into large position drift over a long sequence.\n"
                "----------------------------------------------------"
                "--------\n"
            )

        # --------------------------------------------------------------
        # Initial timestamp
        # --------------------------------------------------------------

        t0_ns = int(
            self.cam0_df["t_ns"].iloc[0]
        )

        return (
            R0,
            bg,
            ba,
            t0_ns
        )

    # ------------------------------------------------------------------
    # Stereo
    # ------------------------------------------------------------------

    def stereo_pair_at(
        self,
        t_ns,
        tol_ns=5_000_000
    ):

        import cv2

        idx0 = (
            self.cam0_df["t_ns"] - t_ns
        ).abs().argmin()

        row0 = self.cam0_df.iloc[idx0]

        idx1 = (
            self.cam1_df["t_ns"] -
            row0["t_ns"]
        ).abs().argmin()

        row1 = self.cam1_df.iloc[idx1]

        if abs(
            int(row1["t_ns"]) -
            int(row0["t_ns"])
        ) > tol_ns:

            raise RuntimeError(
                "cam0/cam1 frames are not synchronized."
            )

        img0 = cv2.imread(
            row0["path"],
            cv2.IMREAD_GRAYSCALE
        )

        img1 = cv2.imread(
            row1["path"],
            cv2.IMREAD_GRAYSCALE
        )

        if img0 is None or img1 is None:
            raise IOError(
                "Unable to read stereo images."
            )

        return (
            int(row0["t_ns"]),
            img0,
            img1
        )

    # ------------------------------------------------------------------

    def num_keyframe_candidates(self, stride=1):
        return len(
            self.cam0_df.iloc[::stride]
        )

    def keyframe_timestamps(self, stride=1):
        return (
            self.cam0_df["t_ns"]
            .iloc[::stride]
            .to_numpy()
        )

    # ------------------------------------------------------------------

    def groundtruth_pose_near(self, t_ns):

        if self.gt_df is None:
            return None

        row = self.gt_df.iloc[
            (
                self.gt_df["t_ns"] -
                t_ns
            ).abs().argmin()
        ]

        q = np.array([
            row["qw"],
            row["qx"],
            row["qy"],
            row["qz"]
        ])

        p = np.array([
            row["px"],
            row["py"],
            row["pz"]
        ])

        return quat_to_R(q), p


def quat_to_R(q):

    q = q / np.linalg.norm(q)

    w, x, y, z = q

    return np.array([
        [
            1 - 2*(y*y + z*z),
            2*(x*y - z*w),
            2*(x*z + y*w)
        ],
        [
            2*(x*y + z*w),
            1 - 2*(x*x + z*z),
            2*(y*z - x*w)
        ],
        [
            2*(x*z - y*w),
            2*(y*z + x*w),
            1 - 2*(x*x + y*y)
        ]
    ])