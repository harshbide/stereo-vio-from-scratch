import numpy as np

from lie import (
    Exp,
    Log,
    right_jacobian_inv
)

from imu_preintegration import GRAVITY


def imu_factor(
    state_i,
    state_j,
    preint
):

    dt = preint.dt

    dR, dv, dp = (
        preint.corrected_deltas(
            state_j.bg,
            state_j.ba
        )
    )

    R_i = state_i.R
    v_i = state_i.v
    p_i = state_i.p

    R_j_pred = (
        R_i @ dR
    )

    v_j_pred = (
        v_i +
        GRAVITY * dt +
        R_i @ dv
    )

    p_j_pred = (
        p_i +
        v_i * dt +
        0.5 * GRAVITY * dt * dt +
        R_i @ dp
    )

    # --------------------------------------------------------------
    # Residual
    # --------------------------------------------------------------

    M = (
        R_j_pred.T @
        state_j.R
    )

    r_R = Log(M)

    r_v = (
        state_j.v -
        v_j_pred
    )

    r_p = (
        state_j.p -
        p_j_pred
    )

    r_bg = (
        state_j.bg -
        state_i.bg
    )

    r_ba = (
        state_j.ba -
        state_i.ba
    )

    residual = np.concatenate([
        r_R,
        r_v,
        r_p,
        r_bg,
        r_ba
    ])

    # --------------------------------------------------------------
    # Jacobian
    # --------------------------------------------------------------

    J = np.zeros(
        (15, 15)
    )

    Jr_inv = right_jacobian_inv(
        r_R
    )

    J[0:3, 0:3] = Jr_inv

    J[3:6, 3:6] = np.eye(3)

    J[6:9, 6:9] = np.eye(3)

    J[9:12, 9:12] = np.eye(3)

    J[12:15, 12:15] = np.eye(3)

    # Bias coupling.

    J[0:3, 9:12] = (
        -Jr_inv @
        M.T @
        preint.dR_dbg
    )

    J[3:6, 9:12] = (
        -R_i @
        preint.dv_dbg
    )

    J[3:6, 12:15] = (
        -R_i @
        preint.dv_dba
    )

    J[6:9, 9:12] = (
        -R_i @
        preint.dp_dbg
    )

    J[6:9, 12:15] = (
        -R_i @
        preint.dp_dba
    )

    # --------------------------------------------------------------
    # Covariance
    # --------------------------------------------------------------

    W = np.zeros(
        (15, 15)
    )

    cov9 = preint.cov.copy()

    # These floors are intentional.
    #
    # The theoretical IMU covariance is extremely small over
    # a single 0.1 s interval, but that does NOT mean the IMU
    # prediction is actually centimeter-perfect.
    #
    # Real errors include:
    #   - accelerometer bias
    #   - gyro bias
    #   - timestamp uncertainty
    #   - integration error
    #   - calibration error
    #   - linearization error
    #
    ROT_FLOOR = (
        1.0e-2
    ) ** 2

    VEL_FLOOR = (
        0.05
    ) ** 2

    # Rebalanced. Previously 0.02 -> weight 2500, which made the IMU
    # position prediction trusted ~6x MORE than the stereo VO factor
    # (weight 400). That is backwards: over a single ~0.1 s keyframe
    # interval a metric stereo PnP solve is centimetre-accurate, while
    # the IMU prediction inherits the (frozen) bias error. With the
    # IMU dominating, VO could not correct accumulating drift.
    POS_FLOOR = (
        0.10
    ) ** 2

    cov9[0:3, 0:3] += (
        ROT_FLOOR *
        np.eye(3)
    )

    cov9[3:6, 3:6] += (
        VEL_FLOOR *
        np.eye(3)
    )

    cov9[6:9, 6:9] += (
        POS_FLOOR *
        np.eye(3)
    )

    cov9 += (
        1e-10 *
        np.eye(9)
    )

    W[0:9, 0:9] = (
        np.linalg.inv(cov9)
    )

    # Bias random walk.
    bg_cov = (
        preint.gyro_bias_rw ** 2
    ) * max(dt, 1e-6) * np.eye(3)

    ba_cov = (
        preint.accel_bias_rw ** 2
    ) * max(dt, 1e-6) * np.eye(3)

    W[9:12, 9:12] = (
        np.linalg.inv(
            bg_cov +
            1e-12 * np.eye(3)
        )
    )

    W[12:15, 12:15] = (
        np.linalg.inv(
            ba_cov +
            1e-12 * np.eye(3)
        )
    )

    return residual, J, W


# ======================================================================
# Visual odometry factor
# ======================================================================

def vo_factor(
    state_i,
    state_j,
    R_rel,
    t_rel,
    n_inliers=None,
    reference_inliers=80,
    rot_sigma=0.02,
    trans_sigma=0.02
):
    """
    n_inliers / reference_inliers: a PnP solution with fewer RANSAC
    inliers is systematically noisier (and more prone to a degenerate
    / wrong-scale solution) than one with many. The previous version
    used the same fixed (rot_sigma, trans_sigma) regardless of how
    many inliers supported the estimate, so a marginal solve (e.g.
    just above min_corners_for_pnp) was trusted exactly as much as a
    solve backed by hundreds of points -- letting weak, occasionally
    wrong, PnP solutions pull the fused estimate around by as much as
    a confident one. Here the effective sigma grows (weight shrinks)
    as the inlier count drops below `reference_inliers`.
    """

    R_i = state_i.R
    p_i = state_i.p

    # Predicted state from stereo VO.
    R_j_pred = (
        R_i @ R_rel
    )

    p_j_pred = (
        p_i +
        R_i @ t_rel
    )

    r_R = Log(
        R_j_pred.T @
        state_j.R
    )

    r_p = (
        state_j.p -
        p_j_pred
    )

    residual = np.concatenate([
        r_R,
        r_p
    ])

    J = np.zeros(
        (6, 15)
    )

    Jr_inv = right_jacobian_inv(
        r_R
    )

    J[0:3, 0:3] = Jr_inv

    J[3:6, 6:9] = np.eye(3)

    # Inflate sigma (shrink weight) when the PnP solve is only weakly
    # supported. Never *shrink* sigma below the nominal value just
    # because there happen to be many inliers -- reference_inliers is
    # a floor, not a target to reward.
    if n_inliers is not None and n_inliers > 0:
        inlier_scale = np.sqrt(
            max(reference_inliers, 1) / float(n_inliers)
        )
        inlier_scale = max(inlier_scale, 1.0)
    else:
        inlier_scale = 1.0

    rot_sigma_eff = rot_sigma * inlier_scale
    trans_sigma_eff = trans_sigma * inlier_scale

    W = np.zeros(
        (6, 6)
    )

    W[0:3, 0:3] = (
        np.eye(3) /
        rot_sigma_eff**2
    )

    W[3:6, 3:6] = (
        np.eye(3) /
        trans_sigma_eff**2
    )

    return residual, J, W

# ======================================================================
# Zero-velocity update (ZUPT)
# ======================================================================

def zupt_factor(state_i, state_j, vel_sigma=0.01):
    """Constrain state_j's velocity to zero.

    Rationale: with the bias states structurally frozen (see the
    initialization validation in dataset.py), the dominant error mode
    is a small residual specific force that ramps velocity linearly
    and therefore drifts position quadratically. Nothing in a
    relative-only factor graph bounds that: IMU and VO factors both
    constrain *relative* motion between consecutive keyframes, so a
    slowly accumulating velocity error is invisible to them.

    A zero-velocity update is one of the few absolute constraints
    available without external positioning. Whenever the platform is
    genuinely stationary, asserting v = 0 directly cancels the
    accumulated velocity error instead of letting it integrate, which
    is by far the cheapest way to bound long-horizon drift.

    Only applied when the caller has detected stationarity (see
    pipeline._is_stationary); applying it while moving would be
    actively harmful, so the detector is deliberately conservative.
    """

    residual = state_j.v.copy()

    J = np.zeros((3, 15))
    J[0:3, 3:6] = np.eye(3)

    W = np.eye(3) / (vel_sigma ** 2)

    return residual, J, W
