"""
On-manifold IMU preintegration between two keyframes.

This is the "IMU factor computation (FPGA)" box in the diagram:
    accumulate raw omega/a samples into delta_R, delta_v, delta_p
    (using the current bias estimate), 100+ Hz.

Follows the standard formulation (Forster, Carlone, Dellaert, Scaramuzza,
"On-Manifold Preintegration for Real-Time VIO", TRO 2017) but written from
scratch with plain numpy -- no GTSAM.

Only first-order bias Jacobians are tracked (dR/dbg, dv/dba, dv/dbg,
dp/dba, dp/dbg), which is enough to correct the preintegrated measurement
cheaply when the bias estimate changes slightly between optimization
iterations, without re-integrating every raw sample.
"""

import numpy as np
from lie import Exp, hat, right_jacobian

GRAVITY = np.array([0.0, 0.0, -9.81007])  # world frame, EuRoC convention (Z up)


class ImuPreintegrator:
    def __init__(self, bg0: np.ndarray, ba0: np.ndarray,
                 gyro_noise_density=1.6968e-4, accel_noise_density=2.0e-3,
                 gyro_bias_rw=1.9393e-5, accel_bias_rw=3.0e-3):
        """bg0/ba0: the bias estimate the raw samples are integrated
        against (the linearization point for the bias Jacobians)."""
        self.bg_lin = bg0.copy()
        self.ba_lin = ba0.copy()

        # preintegrated deltas
        self.dR = np.eye(3)
        self.dv = np.zeros(3)
        self.dp = np.zeros(3)
        self.dt = 0.0

        # first-order Jacobians wrt bias, evaluated at (bg_lin, ba_lin)
        self.dR_dbg = np.zeros((3, 3))
        self.dv_dbg = np.zeros((3, 3))
        self.dv_dba = np.zeros((3, 3))
        self.dp_dbg = np.zeros((3, 3))
        self.dp_dba = np.zeros((3, 3))

        # noise model -> 9x9 covariance of (dR, dv, dp) residual, accumulated
        self.cov = np.zeros((9, 9))
        self._gyro_cov = (gyro_noise_density ** 2) * np.eye(3)
        self._accel_cov = (accel_noise_density ** 2) * np.eye(3)
        self.gyro_bias_rw = gyro_bias_rw
        self.accel_bias_rw = accel_bias_rw

        self.n_samples = 0

    def integrate(self, omega: np.ndarray, accel: np.ndarray, dt: float):
        """Integrate one raw IMU sample (gyro rad/s, accel m/s^2) using
        the current bias estimate at bg_lin/ba_lin. Euler (piecewise
        constant) integration -- simple and adequate for 100-200 Hz IMUs;
        swap for midpoint integration if you need higher accuracy."""
        if dt <= 0:
            return
        w = omega - self.bg_lin
        a = accel - self.ba_lin

        dR_k = Exp(w * dt)

        # --- propagate noise covariance (linear error-state model) ---
        A = np.eye(9)
        B = np.zeros((9, 6))
        a_hat = hat(a)
        A[0:3, 0:3] = dR_k.T
        A[3:6, 0:3] = -self.dR @ a_hat * dt
        A[6:9, 0:3] = -0.5 * self.dR @ a_hat * dt * dt
        A[6:9, 3:6] = np.eye(3) * dt
        B[0:3, 0:3] = right_jacobian(w * dt) * dt
        B[3:6, 3:6] = self.dR * dt
        B[6:9, 3:6] = 0.5 * self.dR * dt * dt
        Q = np.zeros((6, 6))
        Q[0:3, 0:3] = self._gyro_cov / max(dt, 1e-9)
        Q[3:6, 3:6] = self._accel_cov / max(dt, 1e-9)
        self.cov = A @ self.cov @ A.T + B @ Q @ B.T

        # --- propagate bias Jacobians ---
        Jr = right_jacobian(w * dt)
        new_dp_dba = self.dp_dba + self.dv_dba * dt - 0.5 * self.dR * dt * dt
        new_dp_dbg = self.dp_dbg + self.dv_dbg * dt - 0.5 * self.dR @ a_hat @ self.dR_dbg * dt * dt
        new_dv_dba = self.dv_dba - self.dR * dt
        new_dv_dbg = self.dv_dbg - self.dR @ a_hat @ self.dR_dbg * dt
        new_dR_dbg = dR_k.T @ self.dR_dbg - Jr * dt

        self.dp_dba, self.dp_dbg = new_dp_dba, new_dp_dbg
        self.dv_dba, self.dv_dbg = new_dv_dba, new_dv_dbg
        self.dR_dbg = new_dR_dbg

        # --- propagate nominal deltas (do this last, uses old self.dR) ---
        self.dp = self.dp + self.dv * dt + 0.5 * self.dR @ a * dt * dt
        self.dv = self.dv + self.dR @ a * dt
        self.dR = self.dR @ dR_k

        self.dt += dt
        self.n_samples += 1

    def corrected_deltas(self, bg: np.ndarray, ba: np.ndarray):
        """First-order bias correction of the preintegrated measurement
        (avoids re-integrating raw samples when the bias estimate is
        updated by the optimizer)."""
        dbg = bg - self.bg_lin
        dba = ba - self.ba_lin
        dR = self.dR @ Exp(self.dR_dbg @ dbg)
        dv = self.dv + self.dv_dbg @ dbg + self.dv_dba @ dba
        dp = self.dp + self.dp_dbg @ dbg + self.dp_dba @ dba
        return dR, dv, dp

    def predict(self, state_i, bg=None, ba=None):
        """Propagate state_i forward through this preintegrated segment
        to produce a predicted state_j (this is the IMU-only prediction
        used to seed the Gauss-Newton solve and to build the IMU
        factor's residual)."""
        from state import NavState
        bg = self.bg_lin if bg is None else bg
        ba = self.ba_lin if ba is None else ba
        dR, dv, dp = self.corrected_deltas(bg, ba)
        R_j = state_i.R @ dR
        v_j = state_i.v + GRAVITY * self.dt + state_i.R @ dv
        p_j = (state_i.p + state_i.v * self.dt
               + 0.5 * GRAVITY * self.dt ** 2 + state_i.R @ dp)
        return NavState(R_j, v_j, p_j, bg.copy(), ba.copy(), state_i.t + self.dt)
