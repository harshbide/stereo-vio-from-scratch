"""
NavState: the 15-dimensional keyframe state used by every factor.

    tangent layout (matches the diagram: "15 unknowns"):
        [0:3]   delta rotation   (so(3), applied via Exp on the right)
        [3:6]   delta velocity   (R^3, world frame)
        [6:9]   delta position   (R^3, world frame)
        [9:12]  delta gyro bias  (R^3)
        [12:15] delta accel bias (R^3)
"""

from dataclasses import dataclass, field
import numpy as np

from lie import Exp, normalize_rotation

STATE_DIM = 15


@dataclass
class NavState:
    R: np.ndarray = field(default_factory=lambda: np.eye(3))   # world_R_body
    v: np.ndarray = field(default_factory=lambda: np.zeros(3)) # world velocity
    p: np.ndarray = field(default_factory=lambda: np.zeros(3)) # world position
    bg: np.ndarray = field(default_factory=lambda: np.zeros(3))  # gyro bias
    ba: np.ndarray = field(default_factory=lambda: np.zeros(3))  # accel bias
    t: float = 0.0  # timestamp (s)

    def copy(self) -> "NavState":
        return NavState(self.R.copy(), self.v.copy(), self.p.copy(),
                         self.bg.copy(), self.ba.copy(), self.t)

    def boxplus(self, dx: np.ndarray) -> "NavState":
        """Apply a 15-dim tangent-space update. This is the 'ARM updates
        pose: apply dx via Exp() for rotation, plain addition for the
        rest' step from the diagram."""
        assert dx.shape == (STATE_DIM,)
        out = self.copy()
        out.R = normalize_rotation(self.R @ Exp(dx[0:3]))
        out.v = self.v + dx[3:6]
        out.p = self.p + dx[6:9]
        out.bg = self.bg + dx[9:12]
        out.ba = self.ba + dx[12:15]
        return out

    def as_dict(self) -> dict:
        return dict(t=self.t, R=self.R.tolist(), v=self.v.tolist(),
                    p=self.p.tolist(), bg=self.bg.tolist(), ba=self.ba.tolist())
