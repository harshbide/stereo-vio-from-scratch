import numpy as np
import cv2


class StereoVOFrontend:

    def __init__(
        self,
        dataset,
        max_corners=500,
        min_corners_for_pnp=20,
        quality_level=0.01,
        min_distance=15
    ):

        self.ds = dataset

        self.K0 = dataset.cam0_calib.K
        self.dist0 = dataset.cam0_calib.dist

        self.K1 = dataset.cam1_calib.K
        self.dist1 = dataset.cam1_calib.dist

        self.max_corners = max_corners
        self.min_corners_for_pnp = min_corners_for_pnp
        self.quality_level = quality_level
        self.min_distance = min_distance

        # --------------------------------------------------------------
        # Rectification / undistortion
        # --------------------------------------------------------------

        res0 = dataset.cam0_calib.resolution
        res1 = dataset.cam1_calib.resolution

        self._map0x, self._map0y = (
            cv2.initUndistortRectifyMap(
                self.K0,
                self.dist0,
                None,
                self.K0,
                res0,
                cv2.CV_32FC1
            )
        )

        self._map1x, self._map1y = (
            cv2.initUndistortRectifyMap(
                self.K1,
                self.dist1,
                None,
                self.K1,
                res1,
                cv2.CV_32FC1
            )
        )

        # --------------------------------------------------------------
        # Stereo projection matrices
        #
        # T_C0_C1:
        #
        # X_C0 = R_C0_C1 X_C1 + t_C0_C1
        #
        # Therefore:
        #
        # X_C1 = R^T X_C0 - R^T t
        # --------------------------------------------------------------

        self.P0 = self.K0 @ np.hstack([
            np.eye(3),
            np.zeros((3, 1))
        ])

        R01 = dataset.R_cam0_cam1
        t01 = dataset.t_cam0_cam1.reshape(3, 1)

        self.P1 = self.K1 @ np.hstack([
            R01.T,
            -R01.T @ t01
        ])

        self._prev_pts3d_cam0 = None
        self._prev_pts2d = None
        self._prev_img = None

    # ------------------------------------------------------------------

    @staticmethod
    def _undistort(
        pts_px,
        K,
        dist
    ):

        pts = (
            pts_px
            .reshape(-1, 1, 2)
            .astype(np.float64)
        )

        out = cv2.undistortPoints(
            pts,
            K,
            dist,
            P=K
        )

        return out.reshape(-1, 2)

    # ------------------------------------------------------------------

    def _detect_and_triangulate(
        self,
        img0,
        img1
    ):

        # Detect features in left image.
        pts0 = cv2.goodFeaturesToTrack(
            img0,
            maxCorners=self.max_corners,
            qualityLevel=self.quality_level,
            minDistance=self.min_distance,
            blockSize=7,
            useHarrisDetector=False
        )

        if (
            pts0 is None or
            len(pts0) < self.min_corners_for_pnp
        ):
            return None, None

        pts0 = pts0.reshape(-1, 2).astype(
            np.float32
        )

        # --------------------------------------------------------------
        # Stereo KLT
        # --------------------------------------------------------------

        pts1, status, err = cv2.calcOpticalFlowPyrLK(
            img0,
            img1,
            pts0,
            None,
            winSize=(21, 21),
            maxLevel=3,
            criteria=(
                cv2.TERM_CRITERIA_EPS |
                cv2.TERM_CRITERIA_COUNT,
                30,
                0.01
            )
        )

        status = status.reshape(-1).astype(bool)

        if err is not None:
            err = err.reshape(-1)

            status &= (
                np.isfinite(err) &
                (err < 25.0)
            )

        pts0 = pts0[status]
        pts1 = pts1[status]

        if len(pts0) < self.min_corners_for_pnp:
            return None, None

        # --------------------------------------------------------------
        # Undistort before triangulation
        # --------------------------------------------------------------

        u0 = self._undistort(
            pts0,
            self.K0,
            self.dist0
        )

        u1 = self._undistort(
            pts1,
            self.K1,
            self.dist1
        )

        # --------------------------------------------------------------
        # Triangulate
        # --------------------------------------------------------------

        pts4d = cv2.triangulatePoints(
            self.P0,
            self.P1,
            u0.T,
            u1.T
        )

        w = pts4d[3]

        valid_w = np.abs(w) > 1e-10

        pts3d = np.full(
            (len(w), 3),
            np.nan,
            dtype=np.float64
        )

        pts3d[valid_w] = (
            pts4d[:3, valid_w] /
            w[valid_w]
        ).T

        # --------------------------------------------------------------
        # Geometric filtering
        # --------------------------------------------------------------

        good = (
            np.isfinite(pts3d).all(axis=1) &
            (pts3d[:, 2] > 0.2) &
            (pts3d[:, 2] < 40.0)
        )

        pts3d = pts3d[good]
        pts0 = pts0[good]

        if len(pts3d) < self.min_corners_for_pnp:
            return None, None

        return pts3d, pts0

    # ------------------------------------------------------------------

    def process_keyframe(
        self,
        img0,
        img1
    ):

        result = (
            None,
            None,
            0
        )

        # ==============================================================
        # TRACK PREVIOUS KEYFRAME
        # ==============================================================

        if (
            self._prev_pts3d_cam0 is not None and
            self._prev_img is not None
        ):

            pts2d_j, status, err = (
                cv2.calcOpticalFlowPyrLK(
                    self._prev_img,
                    img0,
                    self._prev_pts2d.astype(
                        np.float32
                    ),
                    None,
                    winSize=(21, 21),
                    maxLevel=3,
                    criteria=(
                        cv2.TERM_CRITERIA_EPS |
                        cv2.TERM_CRITERIA_COUNT,
                        30,
                        0.01
                    )
                )
            )

            status = status.reshape(-1).astype(bool)

            if err is not None:
                err = err.reshape(-1)

                status &= (
                    np.isfinite(err) &
                    (err < 25.0)
                )

            # ==========================================================
            # FORWARD / BACKWARD CHECK
            # ==========================================================

            valid_idx = np.flatnonzero(status)

            if len(valid_idx) >= self.min_corners_for_pnp:

                back, back_status, _ = (
                    cv2.calcOpticalFlowPyrLK(
                        img0,
                        self._prev_img,
                        pts2d_j[valid_idx],
                        None,
                        winSize=(21, 21),
                        maxLevel=3
                    )
                )

                fb_error = np.linalg.norm(
                    back -
                    self._prev_pts2d[valid_idx],
                    axis=1
                )

                good_fb = (
                    back_status.reshape(-1).astype(bool) &
                    np.isfinite(fb_error) &
                    (fb_error < 1.5)
                )

                new_status = np.zeros_like(status)

                new_status[
                    valid_idx[good_fb]
                ] = True

                status = new_status

            pts3d_i = (
                self._prev_pts3d_cam0[status]
            )

            pts2d_j_tracked = (
                pts2d_j[status]
            )

            # ==========================================================
            # PNP
            # ==========================================================

            if len(pts3d_i) >= self.min_corners_for_pnp:

                pts2d_j_u = self._undistort(
                    pts2d_j_tracked,
                    self.K0,
                    self.dist0
                )

                ok, rvec, tvec, inliers = (
                    cv2.solvePnPRansac(
                        pts3d_i.astype(np.float32),
                        pts2d_j_u.astype(np.float32),
                        self.K0,
                        np.zeros(4),
                        reprojectionError=1.5,
                        confidence=0.999,
                        iterationsCount=500,
                        flags=cv2.SOLVEPNP_ITERATIVE
                    )
                )

                if (
                    ok and
                    inliers is not None and
                    len(inliers) >= self.min_corners_for_pnp
                ):

                    # Refine using only RANSAC inliers.
                    inlier_idx = (
                        inliers.reshape(-1)
                    )

                    try:
                        rvec, tvec = cv2.solvePnPRefineLM(
                            pts3d_i[inlier_idx].astype(
                                np.float64
                            ),
                            pts2d_j_u[inlier_idx].astype(
                                np.float64
                            ),
                            self.K0,
                            np.zeros(4),
                            rvec,
                            tvec
                        )
                    except Exception:
                        pass

                    R_j_i, _ = cv2.Rodrigues(
                        rvec
                    )

                    # OpenCV gives:
                    #
                    # X_j = R_j_i X_i + t_j_i
                    #
                    # We need:
                    #
                    # X_i = R_i_j X_j + t_i_j
                    #
                    R_rel = R_j_i.T

                    t_rel = (
                        -R_j_i.T @
                        tvec.reshape(3)
                    )

                    translation = np.linalg.norm(
                        t_rel
                    )

                    # Reject only truly nonsensical PnP solutions here.
                    #
                    # NOTE: this used to be the *only* outlier gate
                    # (threshold 2.0 m), which is far looser than a
                    # real keyframe-to-keyframe displacement for a
                    # hand-held/MAV indoor sequence (typically a few
                    # cm at 10-20 Hz keyframe rate). That let PnP
                    # solutions that were wrong by up to ~2 m pass
                    # straight through as "good" measurements, and
                    # those errors accumulated keyframe after keyframe.
                    #
                    # The real, dt-aware/velocity-aware gate now lives
                    # in the pipeline (which compares this VO estimate
                    # against the IMU-preintegrated prediction, and
                    # can also weight the factor by n_inliers). This
                    # check is only a coarse backstop against a
                    # completely degenerate solve.
                    if translation < 10.0:

                        result = (
                            R_rel,
                            t_rel,
                            len(inliers)
                        )

        # ==============================================================
        # REFRESH STEREO MAP
        # ==============================================================

        pts3d, pts2d = (
            self._detect_and_triangulate(
                img0,
                img1
            )
        )

        self._prev_pts3d_cam0 = pts3d
        self._prev_pts2d = pts2d
        self._prev_img = img0

        return result


# ----------------------------------------------------------------------
# Camera relative pose -> body relative pose
# ----------------------------------------------------------------------

def cam_rel_to_body_rel(
    R_rel_cam,
    t_rel_cam,
    R_body_cam,
    t_body_cam
):

    R_bc = R_body_cam
    t_bc = t_body_cam

    R_rel_body = (
        R_bc @
        R_rel_cam @
        R_bc.T
    )

    t_rel_body = (
        t_bc -
        R_rel_body @ t_bc +
        R_bc @ t_rel_cam
    )

    return (
        R_rel_body,
        t_rel_body
    )