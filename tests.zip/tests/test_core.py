"""
Regression tests for the math core (no dataset required). Run with:

    python -m pytest tests/ -v

or directly:

    python tests/test_core.py
"""
import os
import sys
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from lie import Exp, Log, right_jacobian, right_jacobian_inv  # noqa: E402
from state import NavState  # noqa: E402
from imu_preintegration import ImuPreintegrator, GRAVITY  # noqa: E402
from factors import imu_factor, vo_factor  # noqa: E402
from optimizer import optimize_keyframe, gauss_newton_step  # noqa: E402
from dataset import quat_to_R  # noqa: E402
from vo_frontend import cam_rel_to_body_rel  # noqa: E402


def test_so3_exp_log_roundtrip():
    rng = np.random.default_rng(0)
    for _ in range(20):
        phi = rng.standard_normal(3) * 0.5
        R = Exp(phi)
        assert np.allclose(phi, Log(R), atol=1e-6)
        assert np.allclose(R.T @ R, np.eye(3), atol=1e-8)


def test_right_jacobian_inverse_consistency():
    rng = np.random.default_rng(1)
    for _ in range(10):
        phi = rng.standard_normal(3) * 0.7
        assert np.allclose(right_jacobian(phi) @ right_jacobian_inv(phi), np.eye(3), atol=1e-6)


def test_imu_preintegration_stationary():
    pre = ImuPreintegrator(bg0=np.zeros(3), ba0=np.zeros(3))
    dt = 0.005
    accel_reading = -GRAVITY
    for _ in range(200):
        pre.integrate(np.zeros(3), accel_reading, dt)
    s1 = pre.predict(NavState())
    assert np.allclose(s1.v, 0, atol=1e-6)
    assert np.allclose(s1.p, 0, atol=1e-6)
    assert np.allclose(s1.R, np.eye(3), atol=1e-8)


def test_imu_preintegration_constant_rotation():
    pre = ImuPreintegrator(bg0=np.zeros(3), ba0=np.zeros(3))
    dt = 0.005
    for _ in range(200):
        pre.integrate(np.array([0, 0, 1.0]), -GRAVITY, dt)
    err = np.linalg.norm(Log(pre.dR) - np.array([0, 0, 1.0]))
    assert err < 1e-3


def test_imu_factor_jacobian_matches_finite_difference():
    rng = np.random.default_rng(3)
    state_i = NavState(R=Exp(rng.standard_normal(3) * 0.3), v=rng.standard_normal(3) * 0.3,
                        p=rng.standard_normal(3), bg=rng.standard_normal(3) * 0.001,
                        ba=rng.standard_normal(3) * 0.01)
    state_j = NavState(R=Exp(rng.standard_normal(3) * 0.3), v=rng.standard_normal(3) * 0.3,
                        p=rng.standard_normal(3), bg=state_i.bg + rng.standard_normal(3) * 0.0005,
                        ba=state_i.ba + rng.standard_normal(3) * 0.001)
    pre = ImuPreintegrator(bg0=state_i.bg.copy(), ba0=state_i.ba.copy())
    for _ in range(50):
        pre.integrate(rng.standard_normal(3) * 0.2, rng.standard_normal(3) * 1.0 - GRAVITY, 0.005)

    _, J_analytic, _ = imu_factor(state_i, state_j, pre)
    J_num = _numeric_jacobian(lambda sj: imu_factor(state_i, sj, pre)[0], state_j)
    assert np.abs(J_num - J_analytic).max() < 1e-4


def test_vo_factor_jacobian_matches_finite_difference():
    rng = np.random.default_rng(4)
    state_i = NavState(R=Exp(rng.standard_normal(3) * 0.3), p=rng.standard_normal(3))
    state_j = NavState(R=Exp(rng.standard_normal(3) * 0.3), p=rng.standard_normal(3))
    R_rel, t_rel = Exp(rng.standard_normal(3) * 0.2), rng.standard_normal(3) * 0.5

    _, J_analytic, _ = vo_factor(state_i, state_j, R_rel, t_rel)
    J_num = _numeric_jacobian(lambda sj: vo_factor(state_i, sj, R_rel, t_rel)[0], state_j)
    assert np.abs(J_num - J_analytic).max() < 1e-4


def test_gauss_newton_converges_monotonically():
    rng = np.random.default_rng(2)
    state_i = NavState(R=np.eye(3), v=np.array([0.2, 0, 0]))
    omega, accel_body = np.array([0, 0, 0.3]), np.array([0.5, 0, 0])
    dt, T = 0.005, 0.5
    pre = ImuPreintegrator(bg0=np.zeros(3), ba0=np.zeros(3))
    R, v, p = state_i.R.copy(), state_i.v.copy(), state_i.p.copy()
    for _ in range(int(T / dt)):
        R = R @ Exp(omega * dt)
        v = v + (R @ accel_body) * dt
        p = p + v * dt
        pre.integrate(omega, R.T @ ((R @ accel_body) - GRAVITY), dt)
    state_j_true = NavState(R=R, v=v, p=p)

    R_rel = (state_i.R.T @ state_j_true.R) @ Exp(rng.standard_normal(3) * 0.01)
    t_rel = state_i.R.T @ (state_j_true.p - state_i.p) + rng.standard_normal(3) * 0.02
    factor_fns = [lambda si, sj: imu_factor(si, sj, pre), lambda si, sj: vo_factor(si, sj, R_rel, t_rel)]

    state_j = pre.predict(state_i)
    prev_cost = np.inf
    for _ in range(5):
        state_j, cost, dxn = gauss_newton_step(state_i, state_j, factor_fns)
        assert cost <= prev_cost + 1e-9, "cost must not increase during Gauss-Newton"
        prev_cost = cost

    assert np.linalg.norm(Log(state_j_true.R.T @ state_j.R)) < 0.01
    assert np.linalg.norm(state_j_true.p - state_j.p) < 0.01


def test_quat_rotmat_roundtrip():
    from main import rotmat_to_quat  # noqa
    rng = np.random.default_rng(7)
    for _ in range(10):
        R = Exp(rng.standard_normal(3))
        q = rotmat_to_quat(R)
        assert np.allclose(R, quat_to_R(q), atol=1e-6)


def test_cam_rel_to_body_rel_consistency():
    rng = np.random.default_rng(6)
    R_bc, t_bc = Exp(rng.standard_normal(3) * 0.3), rng.standard_normal(3) * 0.05
    R_rel_cam, t_rel_cam = Exp(rng.standard_normal(3) * 0.1), rng.standard_normal(3) * 0.2
    R_rel_body, t_rel_body = cam_rel_to_body_rel(R_rel_cam, t_rel_cam, R_bc, t_bc)

    Xj_cam = rng.standard_normal((5, 3))
    Xi_cam = (R_rel_cam @ Xj_cam.T).T + t_rel_cam
    Xj_body = (R_bc @ Xj_cam.T).T + t_bc
    Xi_body_direct = (R_bc @ Xi_cam.T).T + t_bc
    Xi_body_via_rel = (R_rel_body @ Xj_body.T).T + t_rel_body
    assert np.abs(Xi_body_direct - Xi_body_via_rel).max() < 1e-9


def _numeric_jacobian(residual_fn, state_j, eps=1e-6):
    r0 = residual_fn(state_j)
    J = np.zeros((len(r0), 15))
    for k in range(15):
        dx = np.zeros(15)
        dx[k] = eps
        r_p = residual_fn(state_j.boxplus(dx))
        dx[k] = -eps
        r_m = residual_fn(state_j.boxplus(dx))
        J[:, k] = (r_p - r_m) / (2 * eps)
    return J


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    for t in tests:
        try:
            t()
            print(f"PASS: {t.__name__}")
        except Exception as e:
            print(f"FAIL: {t.__name__}: {e}")
            raise
    print(f"\n{len(tests)} tests passed.")
